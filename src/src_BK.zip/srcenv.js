
//export default{

//var ssrAPI = "http://0.0.0.0:9100"; //server_api
var ssrAPI = "http://127.0.0.1:9101"; //server_api
//var ssrAPI = "http://192.168.1.6:9100"; //server_api
//var serverAPIURL = "http://0.0.0.0:9100"; //server_api
//var ssrmongoseAPI = "http://192.168.1.6:27017"; //database_api
var databaseAPI_URL = "http://0.0.0.0:27017"; //database_api

export { ssrAPI, databaseAPI_URL }
