<template>
  <q-dialog v-model="_fileAsPathSlide" class="column saleitContentOps-Glass">
    <div class="col" v-if="onplayRowItem?.['saleitgr'] ?? false">
      <q-carousel
        animated
        swipeable
        loading="lazy"
        v-model="slideIndex"
        navigation
        infinite
        arrows
        transition-prev="slide-right"
        transition-next="slide-left"
        control-color="amber"
        v-model:fullscreen="slideFullscreen"
        class="bg-grey-9 shadow-2 rounded-borders"
      >
        <q-carousel-slide
          :name="imgindex"
          :img-src="imggr"
          v-for="(imggr, imgindex) in onplayRowItem['saleitgr']"
          :key="imgindex"
        />
        <template v-slot:control>
          <q-carousel-control position="bottom-right" :offset="[18, 18]">
            <q-btn
              push
              round
              dense
              color="white"
              text-color="primary"
              :icon="fullscreen ? 'fullscreen_exit' : 'fullscreen'"
              @click="slideFullscreen = !slideFullscreen"
            />
          </q-carousel-control>
        </template>
      </q-carousel>
    </div>
  </q-dialog>

  <!-- Dialog Windows and ... -->
  <dialogOne
    :isOpen="__this_foreignBoxDialog"
    @emitClick0="__this_foreignBoxDialog = $event"
  >
    <template v-if="__this_foreignBoxDialog == 'fromcart'">
      <div class="boxcstyle" style="padding: 3%; min-width: 30vw">
        <div>
          <div class="fontestyle">Editing on cart Item</div>
          <div class="fontdstyle">
            Order ID : {{ _this_modelOneforeign.orderID }}
          </div>
        </div>

        <div>
          set Quantity
          <buyButton
            style=""
            :quantity="_this_modelOneforeign['quantity']"
            :price="_is_this_netPrice"
            @decreaseButton="
              _this_modelOneforeign['quantity'] =
                parseFloat(_this_modelOneforeign['quantity'] ?? 1) - 1
            "
            @increaseButton="
              _this_modelOneforeign['quantity'] =
                parseFloat(_this_modelOneforeign['quantity'] ?? 1) + 1
            "
          >
          </buyButton>
        </div>

        <div></div>
      </div>
      <div class="row q-pa-sm fontestyle">
        <q-btn
          rounded
          class="col-grow bg-orange text-white fontestyle"
          @click="_this_foreignOperation._newbuyer_foreign('buy', false)"
          >Buy From Carts</q-btn
        >
        <!-- <q-btn rounded class="col-grow bg-green text-white"   @click="_this_foreignOperation._newbuyer_foreign('cart')">ADD to Cart</q-btn> -->
      </div>
    </template>

    <template v-else>
      <div
        class="boxastyle text-black"
        style="padding: 3%; min-width: 30vw"
        :set="(_this_modelOneforeign = _thisDefault_client)"
      >
        <div class="row justify-between items-center q-my-md">
          <div class="fontestyle">Setting New Order</div>
          <div class="fontbstyle">
            OrderID : {{ _this_modelOneforeign.orderID }}
          </div>
        </div>

        <div>
          <div>set Quantity</div>
          <buyButton
            style=""
            :quantity="_this_modelOneforeign['quantity']"
            :price="_is_this_netPrice"
            :currency="_this.currency ?? ''"
            @decreaseButton="
              _this_modelOneforeign['quantity'] =
                parseFloat(_this_modelOneforeign['quantity'] ?? 1) - 1
            "
            @increaseButton="
              _this_modelOneforeign['quantity'] =
                parseFloat(_this_modelOneforeign['quantity'] ?? 1) + 1
            "
          >
          </buyButton>
        </div>

        <div></div>
        <div class="boxbstyle q-my-md"></div>
      </div>

      <div class="row q-pa-sm fontestyle">
        <q-btn
          rounded
          class="col-grow bg-orange text-white fontestyle"
          @click="_this_foreignOperation._newbuyer_foreign('buy', true)"
          >Buy Now</q-btn
        >
        <!-- <q-btn rounded class="col-grow bg-green text-white"   @click="_this_foreignOperation._newbuyer_foreign('cart')">ADD to Cart</q-btn> -->
      </div>
    </template>
  </dialogOne>

  <!-----DEbug ( Action ) Informations-->
  <template v-if="DoneMessage.length ?? false">
    <debugCard :messages="DoneMessage ?? []" @closeButton="DoneMessage = []" />
  </template>
  <template v-if="WarnthisMessage.length ?? false">
    <debugCard
      :messages="WarnthisMessage ?? [{}]"
      @closeButton="WarnthisMessage = []"
    />
  </template>

  <!-----Status ( Store/Loading ) Informations-->
  <!-- <template v-if="status_WarnthisMessage.length ?? false">
    <statusCard :messages="status_WarnthisMessage ?? [{}]" />
  </template> -->
  <template v-if="status_KnowthisMessage.length ?? false">
    <statusCard
      :messages="status_KnowthisMessage ?? [{}]"
      @closeButton="status_KnowthisMessage = []"
    />
  </template>
  <!-- <template v-if="status_DoneMessage.length ?? false">
    <statusCard :messages="status_DoneMessage ?? [{}]" />
  </template> -->
  <!-- <template v-if="status_Loading.length ?? false">
    <statusCard :messages="status_Loading ?? [{}]" />
  </template> -->

  <q-page class="row rounded-borders fontastyle q-py-xs fit boxastyle">
    <div
      class="col-auto q-gutter-xs fixed-bottom z-top column q-ma-md items-end"
      style="left: 70vw"
    >
      <!------------->
      <!--- No Data Founded, but keep listnening till we founde-->
      <div class="q-pa-sm" v-if="syncerrorData">
        {{ syncerrorData }}
      </div>
      <!---Rows is locked but, Update founded-->
      <div
        class="q-pa-sm text-bold rounded-borders fontastyle bg-blue"
        v-if="syncListenerSmsint"
      >
        <div>{{ syncListenerSmsint }}</div>
        <div>Update Now</div>
      </div>
      <!-------------------->
      <!------loading update/create items-->
      <div
        class="q-pa-sm text-bold rounded-borders fontastyle"
        v-if="_onplayRowItemOpsStatus"
      >
        Still Loading...
      </div>
      <!------loading comments/client Operation-->
      <div
        class="text-bold rounded-borders fontastyle"
        v-if="_onplayRowItemsideBoxOpsStatus"
      >
        {{ _onplayRowItemsideBoxOps == "comments" ? "commenting.." : "Buying" }}
      </div>

      <!---custome loading(operation status)-->
      <!-- <div class=" text-bold rounded-borders bg-grey" v-if='Loading'> {{Loading}}  </div>
          <div class=" text-bold rounded-borders bg-green" v-if='DoneMessag'>  {{ DoneMessag}}  </div>
          <div class="  text-bold rounded-borders bg-cyan" v-if='KnowthisMessage'> {{ KnowthisMessage}}  </div>
          <div class="  text-bold rounded-borders bg-red" v-if='WarnthisMessage'> {{ WarnthisMessage}}   </div> -->
    </div>

    <div
      class="col-auto column rounded-borders fontastyle q-gutter-xs boxbstyle"
      style="height: 93svh"
    >
      <!---Quantity Tags-->
      <div
        class="col-auto q-gutter-sm row q-pa-xs justify-between boxastyle bg-orange"
      >
        <div
          class="col-auto row q-gutter-xs column justify-between items-center layout-Glass"
        >
          <div class="row q-gutter-none items-center">
            <q-avatar icon="phone" />
            <div>{{ Objprops._profile.phone }}</div>
          </div>
          <div class="text-white">
            <q-avatar>
              <img :src="Objprops._profile.profile[0]" />
            </q-avatar>
            <div class="fontastyle">
              # {{ Objprops._profile.name }} {{ Objprops._profile.lastName }}
            </div>
          </div>
          <div class="fontestyle text-white">
            <div>My Shops</div>
          </div>
        </div>
        <div class="col-auto row q-gutter-xs">
          <!--q-date v-model="date" /-->

          <q-card-section
            class="column col-auto q-gutter-xs fontastyle shadow-1"
          >
            <div>Search Date:</div>
            <div class="row justify-between q-gutter-sm q-px-xs">
              <div class="text-grey"></div>
              <input class="boxbstyle bg-orange" type="date" />
              <!-- <q-btn label="Choose Date" :dense="true" color="blue" size="sm" @click="showDate = true"  ></q-btn> -->
            </div>
            <q-separator inset />
            <div>Show Store:</div>
            <div
              class="row justify-between q-gutter-sm q-px-xs"
              v-for="(item, kkey) in _storeStatus"
              :key="kkey"
            >
              <div class="text-black">{{ kkey }}</div>
              <div>
                <q-toggle size="xs" v-model="_storeStatus[kkey]" val="xs" />
              </div>
            </div>
          </q-card-section>

          <q-card-section
            class="column col-auto q-gutter-xs fontastyle shadow-1"
          >
            <div>Serve Status:</div>
            <div
              class="row justify-between q-gutter-sm q-px-xs"
              v-for="(sstatus, kkey) in _serveStatus"
              :key="kkey"
            >
              <div class="text-black">{{ kkey }}</div>
              <div>
                <q-toggle size="xs" v-model="_serveStatus[kkey]" val="xs" />
              </div>
            </div>
          </q-card-section>
        </div>

        <div class="col-auto q-gutter-xs row q-pa-none">
          <q-card-section class="shadow-1 col-auto fontastyle q-gutter-xs">
            Total Quantity
            <div class="row q-gutter-none bg-white rounded-borders">
              <div class="q-pa-xs text-grey">{{ storeItems["buy"] }}</div>
              <div class="col-grow q-pa-xs">Bought</div>
            </div>
            <div class="row row q-gutter-none bg-white rounded-borders">
              <div class="q-pa-xs">{{ storeItems["cart"] }}</div>
              <div class="q-pa-xs">On Cart</div>
            </div>
          </q-card-section>

          <!---Price Tags-->
          <q-card-section
            class="shadow-1 col-auto boxastyle column"
            style="background-color: transparent"
          >
            <div class="fontdstyle">Total Budget</div>
            <div class="row flex flex-center col-grow q-gutter-xs">
              <div>{{ totalPrice }}</div>
              <div>{{ _this?.currency ?? "" }}</div>
            </div>
          </q-card-section>
        </div>
      </div>

      <div class="col column q-pa-sm q-ma-none">
        <!-- For enabling common reactivity -->
        <!-- <q-table  
                               style="height:0px;width: 0px;visibility: hidden;"
                               flat bordered
                              :rows="_this_modelOneRows"
                              :columns="columns"
                                      ></q-table>  {{  _this_modelOneRows.length }} -->

        <!------------------------------ ioio ----->
        <div
          class="col q-pa-none column"
          v-if="_this_modelOneRows && (_this_modelOneRows.length ?? false)"
        >
          <q-table
            flat
            bordered
            :rows="_this_modelOneRows"
            :columns="_this_modelOneColumns"
            :filterMethod="_thisFiltering"
            v-model:filter="filter"
            :inFullscreen="true"
            class="col-auto column transparent q-py-md"
            card-class="text-brown"
            color="white"
            no-data-label=""
            :rows-per-page-options="[0]"
            :visible-columns="visible_clientColumns"
            virtual-scroll
            row-key="id"
            rowIndex="true"
            style="background-color: whitesmoke; backdrop-filter: blur(250px)"
            hide-pagination
            hide-top
            hide-bottom
          >
            <template #header-cell="props">
              <q-td
                :props="props"
                style="background-color: orange; backdrop-filter: blur(250px)"
              >
                {{ props.col.name }}
              </q-td>
            </template>

            <template v-slot:body="props">
              <q-tr
                :props="props"
                class="q-gutter-sm col-shrink q-pa-none"
                :style="
                  props.rowIndex == __this_foreignBoxIndex
                    ? 'background-color:orange'
                    : ''
                "
              >
                <td
                  :props="props"
                  style="font-size: 0.6em; text-align: justify"
                  class="text-bold text-start fontestyle"
                  :class="object.name == 'name' ? 'text-start' : 'text-start '"
                  v-for="object in props.cols"
                  :key="object.name"
                >
                  <!--Styling Tabs-->
                  <div v-if="object.name == 'served'" class="fontestyle">
                    <div
                      :style="
                        props.row[object.name] == 'Requested'
                          ? 'color:green'
                          : 'color:grey'
                      "
                    >
                      {{ props.row[object.name] }}
                    </div>
                  </div>
                  <!---------------Store columns-->
                  <div v-else-if="object.name == 'store'">
                    <q-badge
                      color="orange"
                      v-if="props.row[object.name] == 'buy'"
                    >
                      Ordered</q-badge
                    >
                    <q-badge color="teal" v-else>Carted</q-badge>
                  </div>

                  <!---------------Descriptions columns-->
                  <div v-else-if="object.name == 'description'">
                    <q-btn
                      :dense="true"
                      rounded
                      class="fontbstyle"
                      no-caps
                      color="blue"
                      label="Show Detail"
                      icon="more"
                      @click="
                        _this_foreignOperation.selectedIndex_RowDetail(
                          props.row['saleitID'],
                          props.rowIndex,
                          'view'
                        )
                      "
                    />
                    <q-card
                      v-if="__this_foreignBoxIndex == props.row.id"
                      class="fixed-bottom z-top fontastyle flex flex-center"
                      style="max-width: 30vh; left: 1rem; bottom: 1rem"
                    >
                      {{ props.row.description }}
                    </q-card>
                  </div>

                  <!---------------time _this_modelOneColumns-->

                  <div
                    v-else-if="object.name == 'time'"
                    class="fontastyle text-grey"
                  >
                    <div
                      v-if="typeof props.row.fupdatedAt == 'object'"
                      class="fontcstyle row q-gutter-xs"
                    >
                      <div v-if="props.row.fupdatedAt?.days ?? ''">
                        {{ props.row.fupdatedAt.days }} D :
                      </div>
                      <div v-if="props.row.fupdatedAt?.hours ?? ''">
                        {{ props.row.fupdatedAt.hours }} H :
                      </div>
                      <div v-if="props.row.fupdatedAt?.minutes ?? ''">
                        {{ props.row.fupdatedAt.minutes }} M
                      </div>
                      <div v-if="props.row.fupdatedAt?.minutes ?? ''">ago</div>
                      <div v-else>Just Now</div>
                    </div>
                    <div v-else>{{ props.row.fupdatedAt }}</div>
                  </div>
                  <div v-else-if="object.name == 'action'" class="q-gutter-xs">
                    <template
                      v-if="
                        __this_foreignBoxIndex == props.rowIndex &&
                        __this_foreignBoxsubOps == 'edit'
                      "
                    >
                      <div class="q-gutter-xs row">
                        <div class="column q-gutter-xs">
                          <q-btn
                            size="sm"
                            color="orange"
                            :dense="true"
                            icon="close"
                            @click="__this_foreignBoxIndex = null"
                            label="close"
                          >
                          </q-btn>
                          <q-btn
                            color="red"
                            size="xs"
                            :dense="true"
                            icon="delete"
                            @click="
                              _this_foreignOperation._remove(props.rowIndex)
                            "
                            label="delete"
                          />
                        </div>
                      </div>
                    </template>
                    <template v-else>
                      <q-btn
                        size="sm"
                        :dense="true"
                        color="orange"
                        icon="edit"
                        @click="
                          _this_foreignOperation.selectedIndex_RowDetail(
                            props.row.saleitID,
                            props.rowIndex,
                            'edit'
                          )
                        "
                      >
                      </q-btn>
                    </template>
                  </div>
                  <!---------------Others _this_modelOneColumns-->

                  <!---------------Others columns-->

                  <div v-else class="fontdstyle">
                    {{ props.row[object.name] }}
                  </div>
                </td>
              </q-tr>
            </template>
          </q-table>
        </div>

        <!-- sckelton of single_content-->
        <div
          class="col q-py-md fit q-gutter-md flex flex-center column"
          style=""
          v-else
        >
          <div style="width: 80%" class="col-grow q-pa-xs row q-gutter-xs">
            <q-skeleton class="col-grow flex flex-center"
              >Searching for your shops
            </q-skeleton>
          </div>

          <q-separator inset />
          <div class="row items-center q-gutter-sm">
            <div></div>
            <div class="fontastyle text-red">No shops Detected, so far</div>
          </div>
        </div>
      </div>
    </div>

    <div
      class="col-grow boxastyle q-pa-xs"
      v-if="__this_foreignBoxIndex != null && Object.keys(_this).length"
    >
      <div class="col boxastyle" style="">
        <q-item class="items-start">
          <q-item-section top avatar>
            <q-avatar color="primary" text-color="white" icon="phone" />
          </q-item-section>

          <q-item-section>
            <q-item-label>{{ _this.fphone }}****</q-item-label>
            <q-item-label
              caption
              v-if="typeof _this.fupdatedAt == 'object'"
              class="text-grey row q-gutter-xs"
            >
              <div>Last Updated :</div>
              <div v-if="_this.fupdatedAt?.days ?? ''">
                {{ _this.fupdatedAt.days }} D,
              </div>
              <div v-if="_this.fupdatedAt?.hours ?? ''">
                {{ _this.fupdatedAt.hours }} H,
              </div>
              <div v-if="_this.fupdatedAt?.minutes ?? ''">
                {{ _this.fupdatedAt.minutes }} M
              </div>
              <div>ago</div>
            </q-item-label>
            <q-item-label class="text-grey row q-gutter-xs" caption v-else>
              {{ _this.fupdatedAt }}
            </q-item-label>
          </q-item-section>

          <q-item-section side top>
            <q-item-label caption> </q-item-label>
            <q-badge
              class="q-pa-sm text-bold"
              v-if="_this.discount ?? false"
              color="pink"
            >
              HH Price :
              <q-item-label class="text-strike text-orange">{{
                _this.price
              }}</q-item-label
              >{{ _this.discount }} {{ currency }}
            </q-badge>
            <q-badge class="q-pa-sm fontestyle" color="orange" v-else>
              {{ _this.price }} {{ currency }} (Price)
            </q-badge>
            <div class="text-orange">
              <q-rating v-model="_this._itServiceRating" :max="5" size="xs" />
            </div>
          </q-item-section>
        </q-item>
      </div>

      <div>
        <q-img
          loading="lazy"
          :src="
            _fileAsPathIndex
              ? _this.saleitgr[_fileAsPathIndex]
              : _this.saleitgr[0]
          "
          spinner-color="orange"
          class="column rounded-borders fit shadow-1"
          style="max-width: 100%; border-radius: 5px; aspect-ratio: 2/1"
        >
          <q-list
            class="column col fit fontbstyle q-px-none"
            :class="_this.phone ? 'transparent' : 'transparent'"
          >
            <q-item
              class="col-auto row items-top q-px-none justify-between items-start"
            >
              <div
                class="col-sm-5 col-md-3 q-py-none fit-width q-gutter-xs"
                style=""
              >
                <q-btn
                  flat
                  :dense="true"
                  icon="zoom_in"
                  @click="_fileAsPathSlideCall()"
                >
                  <q-tooltip>Look Closer</q-tooltip>
                </q-btn>
              </div>

              <div class="col-auto q-px-none q-mx-none" v-if="$q.screen.lt.sm">
                <q-item class="q-px-none"> </q-item>
              </div>

              <!--q-item-section class="col columns row items-end float" >
                                                                <q-item-label>D_QueryW {{ _this.queryWeight}} </q-item-label>
                                                                <q-item-label>Prof_W {{ Objprops._profile.queryWeight}} </q-item-label>
                                                                <q-item-label> Revenu:- {{ _this['tPrice'] }}</q-item-label>
                                                        </q-item-section--->
            </q-item>

            <q-item
              class="col-auto row justify-between content-start q-px-none q-mx-none"
            >
            </q-item>

            <q-item
              class="absolute-bottom fontdstyle items-center q-gutter-sm row items-end"
            >
              <div class="col row" v-if="$q.screen.gt.sm">
                <!---------------------Conteting While in NOT Mobile Screen-->
              </div>

              <div class="col row" v-else>
                <!---------------------Conteting While in Mobile Screen-->
                <q-item-section class="q-py-sm fontbstyle col row">
                  <div class="col-auto column justify-start q-pa-sm">
                    <div class="col-auto row q-pa-xs q-ma-none">
                      <div
                        class="col-auto justify-right q-py-none saleitContentOps-Glass"
                      >
                        {{ _this.header }}
                      </div>
                    </div>
                  </div>
                </q-item-section>

                <q-item-section
                  class="row col-auto q-px-none text-sm saleitContentOps-Glass"
                >
                  <div>
                    Revenue: {{ _this.tPrice }}
                    <q-item v-if="typeof _this.timer ?? false">
                      <q-item-section> </q-item-section>
                    </q-item>
                  </div>

                  <q-separator inset />
                  <div v-if="_this.clients ?? false">
                    Buyers : {{ _this.tClient }}
                  </div>
                  <q-separator inset />
                  <div v-if="_this.clients ?? false">
                    Quantity : {{ _this.quantity }}
                  </div>
                </q-item-section>
              </div>
            </q-item>
          </q-list>
        </q-img>
      </div>

      <div class="row q-gutter-sm">
        <q-item class="col column q-gutter-sm">
          <div
            class="col row no-padding no-margine q-gutter-xs"
            style="border: 0px solid orange"
          >
            <q-btn
              outline
              v-for="(item, fileIndx) in _this.saleitgr"
              @click="_fileAsPathOpsCall(fileIndx)"
              :key="fileIndx"
              class="col-1 column transparent q-pa-none no-border"
              style="max-width: 6dvw"
            >
              <img
                :src="item"
                class="col fit shadow-2 transparent rounded-borders q-pa-none"
                style="aspect-ratio: 2/1; width: 100%"
              />
            </q-btn>
          </div>

          <div class="col-auto column q-gutter-sm">
            <q-item-section style="color: blue"> Item Details </q-item-section>

            <q-item-section class="boxbstyle rounded-borders shadow-1">
              <q-item-label>{{ _this["header"] }}</q-item-label>
              <q-item-label caption>{{ _this["description"] }} </q-item-label>
            </q-item-section>
            <div class="q-gutter-xs row">
              <q-item-section class="boxbstyle rounded-borders shadow-1">
                <q-item-label>Available Quantities</q-item-label>
                <q-item-label class="text-grey">
                  {{ _this["quantity"] ? _this["quantity"] : "Sold Out" }}
                </q-item-label>
              </q-item-section>

              <q-item-section class="boxbstyle rounded-borders shadow-1">
                <q-item-label>Total Buyers</q-item-label>

                <q-item-label class="text-grey row justify-center">
                  {{ _this["tClient"] }}
                </q-item-label>
              </q-item-section>
            </div>
          </div>
          <div
            class="col-grow column q-gutter-sm"
            v-if="__this_foreignBoxIndex != null"
          >
            <q-separator inset />

            <div class="fontestyle text-orange">Your Order Details</div>
            <div class="q-gutter-xs row">
              <q-item-section class="boxbstyle rounded-borders shadow-1">
                <q-item-label>Quantity</q-item-label>
                <q-item-label caption>{{
                  _this_modelOneforeign["quantity"]
                }}</q-item-label>
              </q-item-section>

              <q-item-section class="boxbstyle rounded-borders shadow-1">
                <q-item-label>Total Price</q-item-label>
                <q-item-label caption>{{
                  _this_modelOneforeign["price"]
                }}</q-item-label>
              </q-item-section>

              <q-item-section class="boxbstyle rounded-borders shadow-1">
                <q-item-label>Order Date</q-item-label>
                <q-item-label
                  caption
                  v-if="typeof _this_modelOneforeign.fupdatedAt == 'object'"
                  class="text-grey row q-gutter-xs"
                >
                  <div v-if="_this_modelOneforeign.fupdatedAt?.days ?? ''">
                    {{ _this_modelOneforeign.fupdatedAt.days }} D,
                  </div>
                  <div v-if="_this_modelOneforeign.fupdatedAt?.hours ?? ''">
                    {{ _this_modelOneforeign.fupdatedAt.hours }} H,
                  </div>
                  <div v-if="_this_modelOneforeign.fupdatedAt?.minutes ?? ''">
                    {{ _this_modelOneforeign.fupdatedAt.minutes }} M
                  </div>
                  <div>ago</div>
                </q-item-label>
                <q-item-label v-else>
                  {{ _this_modelOneforeign.fupdatedAt }}
                </q-item-label>
              </q-item-section>
            </div>

            <q-item-section class="boxbstyle rounded-borders">
              <q-item-label>Serve Status</q-item-label>
              <q-item-label
                caption
                v-if="_this_modelOneforeign['served'] == 'Requested'"
                >{{ _this_modelOneforeign["served"] }}</q-item-label
              >
              <q-item-label caption v-else style="color: orange">{{
                _this_modelOneforeign["served"]
              }}</q-item-label>
            </q-item-section>
            <q-item-section class="boxbstyle rounded-borders">
              <q-item-label>Notes</q-item-label>
              <q-item-label caption>{{
                _this_modelOneforeign["description"]
              }}</q-item-label>
            </q-item-section>
          </div>
        </q-item>

        <q-item
          class="column col-auto justify-center q-gutter-sm"
          v-if="_this_modelOneforeign?.quantity ?? false"
        >
          <q-btn icon="numbers" no-caps color="green"
            >Qts {{ _this_modelOneforeign["quantity"] }}
          </q-btn>
          <q-btn color="orange"
            >{{ _this_modelOneforeign["price"] }} {{ _this.currency }}</q-btn
          >
        </q-item>
      </div>
      <div
        class="flex flex-center q-gutter-sm q-pa-sm text-black"
        v-if="_is_this_open"
      >
        <q-btn
          icon="edit"
          color="green"
          rounded
          @click="__this_foreignBoxDialog = 'fromcart'"
          :dense="true"
          v-if="_this_modelOneforeign.store == 'cart'"
        >
          <q-tooltip> Edit On Cart Items !</q-tooltip>
        </q-btn>

        <template v-if="__this_foreignBoxsubOps == 'view'">
          <q-btn
            icon="add"
            color="green"
            rounded
            :dense="true"
            @click="__this_foreignBoxDialog = 'buy'"
            style="background-size: 5px"
          >
            New Order
          </q-btn>
        </template>
      </div>
    </div>
    <div class="col flex flex-center fontbstyle" v-else>
      <div v-if="__thisOpsStatus">
        <q-spinner color="primary" size="3em" :thickness="2" />
        <div style="font-weight: lighter; font-size: 12px">Loading</div>
      </div>
      <div v-else style="font-size: 43px; font-weight: bolder; color: red">
        Product doesn't founded.
      </div>
    </div>
    <!----------------------LiveDATA Banner-->
    <!------------Zooming Level Adjuster Sticky-------------------------->
  </q-page>
</template>

<script setup>
//_____________________________________________Modules Definitions
//-------------------------------------------------------------Importing System Modules
import {
  ref,
  reactive,
  computed,
  watch,
  onUnmounted,
  onMounted,
  defineComponent,
} from "vue";
import { useQuasar, useMeta } from "quasar";
//import print from 'print-js';
import { useRouter } from "vue-router";
//import { storeToRefs } from "pinia";
//---------------stores
import { thisStore } from "@/stores/dataStores/thisStore"; //saleit Store ( Main Store)

// import { saleitSchema } from "@/composables/schemas/saleitSchemas";
// import { saleitClientSchema } from "@/composables/schemas/saleitSchemas";
// import { saleChatSchema } from "@/composables/schemas/chatSchemas";

import _genOrderID from "@/composables/utilServices/idGenerator";
import useschemaValidator from "src/composables/utilServices/schemaValidator";
const {
  thisSchemaPath,
  thisSchemaFile,
  //------------
  _debugObj,
  //-------
  _validateThis,
} = useschemaValidator();
// useschemaValidator
// import  {_isnull,_isempty,_isequ,_isgte,_islte,_isbtn} from "@/composables/validators"
import {
  saleCatagory,
  saleUsage,
  _createTitle,
  _updateTitle,
  _readTitle,
  _deleteTitle,
} from "@/composables/constVariables";

import buyButton from "src/components/buttons/buyButton.vue";
import closeButton from "src/components/buttons/closeButton.vue";

import confirmButton from "src/components/buttons/confirmButton.vue";
let confirmObj = ref(null);
let confirmMessage = ref("Are You Sure ?");

import dialogOne from "src/components/dialogs/dialogOne.vue";
const status_thisDetail = ref(null);

import useThisMixin from "src/composables/thisMixin";
var {
  //----------//-- settings
  _is_modelOneOwner,
  _is_this_netPrice,
  _is_this_open,
  // __thisBox_CDialog,
  __thisBox,
  //----------//--
  __thisIndex,
  __thisOps,
  __thisOpsStatus,
  //---------//-- functions
  // set_this,
  //====================
  __this_foreignBox,
  __this_foreignBoxDialog,
  //--------
  __this_foreignBoxIndex,
  __this_foreignBoxOps,
  __this_foreignBoxOpsStatus,
  __this_foreignBoxsubOps,
  //---
  // set_this_foreign,
  // __thisBox_UDialog,
  // set_this,
} = useThisMixin();

import useDefaulMixin from "@/composables/myMixin";
let {
  count,
  //------------
  //----------returning values
  _allColumnNames,
  _rolesColumns,
  visibleColumns,

  //---------settings
  Objprops_,
  _thisModel,
  _this_Schema,

  lockedColumns,
  invisibleColumns,
  //----------------functions
  _allColumnName,
  _rolesColumn,
  visibleColumn,

  _this_Rows,
  _this_Details,

  _this,

  columns,
  _this_Query,
  _this_RowsStatus,
  //-----------//-- returning values
  _thisDefault,

  _thisModels,
  modal_iss,

  //functionsssss
  //------preparing the main default and table_design.
  _this_Defaulting,
  //------preparing the foreign default and table_design
  foreign_Columns,
  _this_foreignDefaulting,

  //------
  visible_clientColumns,
} = useDefaulMixin();

import useClientMixin from "@/composables/thisClientMixin";
var {
  _this_modelOneSchema,

  _this_modelOneColumns,
  visibleColumns_client,
  invisibleColumns_client,

  _modelOneQuery,

  _this_modelOneRows,
  _this_modelOneDetails,
  _thisDefault_client,
  _this_modelOneforeign,
  _is_modelOneOwner,
} = useClientMixin();

import useChatMixin from "@/composables/thisChatMixin";
var {
  _this_chatSchema,

  _this_chatColumns,
  visibleColumns_chat,
  invisibleColumns_chat,

  _chatQuery,

  _this_modelTwoRows,
  _thisDefault_chat,
  _this_chatforeign,
  _is_chatOwner,
} = useChatMixin();

import debugCard from "@/components/debugCards.vue";
import useDebugMixin from "@/composables/debugMixin";
const {
  Loadingpage,
  Loadingevent,

  DoneMessage,
  WarnthisMessage,
  //----------returning values
  timerLoadevent,

  timerDone,
  timerError,
} = useDebugMixin();

import statusCard from "@/components/statusCards.vue";
import useStatusMixin from "@/composables/statusMixin";
const {
  status_KnowthisMessage,
  //----------returning values
  status_timerInformthis,
} = useStatusMixin();

import usefileMixin from "@/composables/fileserviceMixin";
var {
  _thisMedia,
  _fileAttributeName,
  //-------
  _cameraBox,
  _fileSourceFoCam,
  _fileAsSRC,
  _fileAsRaw,

  _liveFeedSRC,
  _fileAsSRCIndex,
  //---
  _cameraDevice,
  _listCameraSource,
  _selectedCameraById,
  _selectedCameraByface,
  _liveFeedRawStreaming,
  //--------
  _fileSourceFolder,
  //--------
  _fileAsSRCOps,
  _fileAsSRCOpsCall,
  //-----------
  _resetFileSource,
  //---
  // set_this_foreign,
} = usefileMixin();

// import { saleitSchema } from "src/composables/schemas/saleitSchemas";
import _localStorage from "src/services/storeService";

const $q = useQuasar();
//const $m = useMeta();
const router = useRouter();

let Objprops = defineProps({
  //----General Informations
  _profile: { type: Object, default: () => ({}) }, //user Datas all there is...
  //----User Credentials and Unique ID.
  //-----------access Parameters
  // _iss: { type: Object, default: () => ({}) }, ///Customized(is?)_ACCESS_Type of Per/User(for_all Models)..as 'saleit':[isUpgrade,isClient] Form
  _acctype: { type: Object, default: () => {} }, ///RAW_ACCESS_Type of Per/User (for_all Models)..as 'saleit':[true,'/plat','',[]]
  // //---------
  // _threeaSchema: { type: Object, default: () => ({}) }, //(Every Models _Schema for ACCEss Type)
  //-------------------(layout tunnel for command datas(signal))
  lytCreatRow: { type: Boolean, default: false },
  //--------Search Button Signal
  lytSearchRow: { type: String, default: "" },
  //----------
  isScrolled: { type: Boolean, default: false }, //isScrolledUp
  isScrolledUp: { type: Boolean, default: false }, //isScrolledUp
  //--------------
  _pageSetting: { type: Object, default: () => ({}) },
});
//===========================================================================////////////////////

import { saleitStore } from "@/stores/dataStores/saleitStore"; //saleit Store ( Main Store)
import { saleitClientStore } from "@/stores/dataStores/saleitClientStore"; //saleit Store ( Main Store)
import { salechatStore } from "@/stores/dataStores/salechatStore"; //saleit Store ( Main Store)

import { useRowFilter } from "@/composables/filters/cartfilter";
var {
  totalPrice,
  storeItems,
  serveItems,
  _enableRowFilter,
  _thisFiltering,
  _filteredRow,
} = useRowFilter();
_enableRowFilter.value = false;

const metaData = {
  // sets document title
  title: "cart",
  // optional; sets final title as "Index Page - My Website", useful for multiple level meta
  titleTemplate: (title) => `${title} - `,
  // JS tags
  icon: "/icons/qimage.png",
  script: {},
};
useMeta(metaData);
//----STORE & SERVICES
thisSchemaPath.value = "saleitSchemas";
thisSchemaFile.value = "saleitSchema";
import("../composables/schemas/" + thisSchemaPath.value)
  .then((module) => {
    _this_Schema.value = module[thisSchemaFile.value];
  })
  .catch((error) => {
    console.error("Error importing schema:", error);
  });

//---foreignKeyed Defaulting (Scheam)==== PreDefined Models
_thisModel.value = "saleitClient"; // the Vue_Page_DataModel (Listing Collection Name)
var _thisModelHeader = ref(_thisModel.value + " Managment"); // the Vue_Page_Data_Headers(Descriptions...)
// _this_Schema.value = saleitSchema;

const _thisService = thisStore();
const _thisModelService = saleitStore();

const modelOneService = saleitClientStore();
const modelTwoService = salechatStore();

const _thisapiUrl = "/saleitapi/saleit";

//==========Global Variables for Data

let priceFilter = { gt: false, lt: false, eq: false };
let _serveStatus = reactive({ Requested: true, Queed: true, Served: true });
let _storeStatus = reactive({ cart: true, buy: true });
//-----searaching on/off
//------------Setting up all the search attributes (is given to the table Data...)
//just list out all possible comparison logics against every row datas
const filter = computed(() => {
  console.log("searchig", Objprops.lytSearchRow);
  return {
    search: Objprops.lytSearchRow,
    //------(Served Columns(Options))
    //Requesting:_serveStatus.Requesting,
    Requested: _serveStatus.Requested,
    Queed: _serveStatus.Queed,
    Served: _serveStatus.Served,
    //-------store Columns (options)
    cart: _storeStatus.cart,
    buy: _storeStatus.buy,
    // //----------
    priceFilter,
  };
});

// let status_dialogBuyer = ref(false)
//================================================================================/////////////
//
let _this_acctype = ref({});
Objprops_.value = Objprops;
_this_acctype = computed(() => {
  if (Objprops._acctype ?? false) {
    return Objprops._acctype[_thisModel.value] ?? null;
  } else {
    return null;
  }
});

// _thisMedia.value = Objprops._thisMedia2;
//------- Objprops.lytSearchRow
watch(Objprops._pageSetting, (_nowValue, ov) => {
  _pageSettings.value = Object.assign(_pageSettings.value, _nowValue);
  return true;
});
watch(_filteredRow, (_nowValue, ov) => {
  Objprops.lytSearchRow ?? false ? this_Query("lytSearchRow") : "";
  return true;
});
// let __thisBox_CDialogh =ref(false)
let __thisBox_CDialog = computed(() => {
  return Objprops.lytCreatRow;
});
watch(__thisBox_CDialog, async (cv, ov) => {
  await set_this("CreateRowItem", null);
  __thisBox.value = true;
  return true;
});
async function __thisBox_UDialog(_playrowIndex = null) {
  _fileAttributeName.value = null;
  await set_this("UpdateRowItem", _playrowIndex);
  __thisBox.value = true; //OPen the Box
  return true;
}
//-----------------Reactive Values
// let watch_this =computed(()=>{return _this.value})
watch(_this, (_nowRows, ov) => {
  if (__thisIndex.value == null) {
    return true;
  }
  // console.log('watching this',_nowRows,__thisIndex.value,__thisBox.value)
  try {
    _is_modelOneOwner.value = _nowRows["userID"] == Objprops._profile.id;
    _is_chatOwner.value = _nowRows["userID"] == Objprops._profile.id;
    _is_this_open.value = _nowRows["quantity"] && _nowRows["price"];
    _is_this_netPrice.value = parseInt(
      _nowRows["discount"] ? _nowRows["discount"] : _nowRows["price"]
    );
  } catch {
    [_is_modelOneOwner.value, _is_this_open.value, _is_this_netPrice.value] = [
      false,
      false,
      false,
    ];
  }

  return true;
});

let watch_Rows = ref(null);
watch_Rows = computed(() => {
  return _thisModelService.getstatus_Rows;
});

watch(watch_Rows, async (StatusRows, ov) => {
  let information;
  if (StatusRows == null) {
    information = "No Data.";
  } else if (StatusRows == "noupdates") {
    information = "No Updates.";
  } else if (StatusRows == false) {
    information = "Locked";
  } else if (StatusRows == true) {
    information = "Loading ....";
  } else if (StatusRows == "BadConnection") {
    information = "Offline";
  } else {
    information = StatusRows;
    // await  timerLoadevent({ 'message': 1 }, 5000, "...Session Closed");
    StatusRows == "Unauthorized" ? _logOut() : "";
    return false;
  }
  status_timerInformthis(5000, information, "Product & Services");
  return true;
});

//-----while selecting different saleit Content
async function set_this(Ops, rowIndex) {
  //---reset Image Related
  _fileAttributeName.value = null;
  _fileAsPathIndex.value = null;
  //-----Reset Data Creating
  __thisBox.value = false; //OPen the Box
  //----Reseting the current Row Values ( ad default, choosen Row)

  _this.value = Object.assign(
    {},
    rowIndex == null ? _thisDefault.value : _this_Rows.value[rowIndex]
  );

  //----assigning Onplay Row
  //------Meta Data relating to current Row values
  __thisIndex.value = rowIndex;
  __thisOps.value = Ops;
  __thisOpsStatus.value = false;
  return true;
}

async function set_this_foreign(foreignOps, _foreignIndex) {
  console.log("Foreign index initialized with ", _foreignIndex);
  //Reseting Default Foreign_Rows (null Index)
  __this_foreignBoxIndex.value = _foreignIndex; //? _foreignIndex : null;
  __this_foreignBox.value = true; //disasble sideBox
  __this_foreignBoxDialog.value = null;
  __this_foreignBoxOps.value = foreignOps; //diable andy operations
  __this_foreignBoxOpsStatus.value = false; //turnofff active stauts
  __this_foreignBoxsubOps.value = false;

  //Reset Initiated from Array Selecting
  if (foreignOps == "clients") {
    _thisDefault_client.value["orderID"] = await _genOrderID();
    _this_modelOneforeign.value = Object.assign(
      {},
      _foreignIndex == null
        ? _thisDefault_client.value
        : _this_modelOneRows.value[_foreignIndex]
    );
  } else if (foreignOps == "comments") {
  }
  _this_modelOneforeign.value["saleitID"] = _this.value?.["id"] ?? "";

  return true;
}
const _resetBoth = async function (resetforeign = null, resumeSync = null) {
  //reset_default if same_index and Ops occured
  try {
    await set_this(resetforeign, null);
  } catch {}
  try {
    await set_this_foreign(resetforeign, null);
  } catch {}
  if (resumeSync) {
    resumeSync.set_syncLock(false);
  }
  return true;
};
const _setBoth = async function (
  setforeign = null,
  _thisindex,
  _foreignIndex = null,
  stopSync = null
) {
  //reset_default if same_index and Ops occured
  try {
    await set_this(setforeign, _thisindex);
  } catch {}
  try {
    await set_this_foreign(setforeign, _foreignIndex);
  } catch {}
  if (stopSync) {
    stopSync.set_syncLock(true);
  }
  return true;
};
//==============================================------------------------------------
let enableflscreen = ref(true);
//--------------
//==========================================DEfaulting && Scheam Generations====Start
//========<><><><><><==================Create Default Schemas

//==========-----------Generating====The Schematic Models
invisibleColumns.value = []; //defualt hidden columns
if ($q.screen.lt.md) {
} //invisibleColumns.push("storeStatus");
if ($q.screen.lt.lg) {
} //invisibleColumns.push("storeStatus");
// _this_Schema.value = saleitSchema
//-------------Syncing Columns
columns = computed(() => {
  //compute for _this_acctype.value
  console.log(
    `\n\n Creating ${_thisModel.value}  Table Schema with AccTypeof ${_this_acctype.value}`
  );
  if (!_this_acctype.value) {
    return [];
  } else {
    let _tableColumn = []; //HOLDING_  all the ---"Columns"--- of the Data_model ( TOTAL Columns)
    let _visibleColsName = []; ////--HOLDING_ all the ---"Visible" Columns"---- of the Data_model ( TOTAL Columns)

    //-------<<<<>>>>-------Preparing this_model role_schemas
    let rolesWall = _this_acctype.value.role ?? false;
    let capabilityWall = _this_acctype.value.capability ?? false;
    let modelRole = _this_acctype.value.roles ?? []; //accstage
    console.log(
      `\n\n User Role & Permissions:_ rolesWall = ${rolesWall} && capabilityWall = ${capabilityWall} && modelRole = ${modelRole}`
    );

    for (let schemaColumn in _this_Schema.value) {
      let _col = {
        name: schemaColumn,
        schema: _this_Schema.value[schemaColumn],
        label: schemaColumn,
        //sortable: true,
        align: "left",
        //sort: (a, b) => a - b,
      };
      _tableColumn.push(_col);
      //----------------loging all columns name as normal list format
      _allColumnName(schemaColumn);
      //---------------loging Visible Columns list(on table)
      invisibleColumns.value.includes(schemaColumn)
        ? ""
        : _visibleColsName.push(schemaColumn);
      //----
      if (
        schemaColumn === "extraColumn" ||
        lockedColumns.value.includes(schemaColumn)
      ) {
        continue;
      } else {
        //Create and Write
        try {
          if ([capabilityWall[0], capabilityWall[2]].includes("2")) {
            ///if user_ hass full access
            if (modelRole.includes(schemaColumn)) {
              //excludes specifed columns
              continue;
            } else {
              _rolesColumn(_col);
            } //gives
          } else if (capabilityWall[0] == "1") {
            //Registererars (checking create digits will work for writing(updating too))
            if (modelRole.includes(schemaColumn)) {
              //excludes specifed columns
              // _rolesColumn(_col);
              continue;
            } else {
              _rolesColumn(_col);
            } //gives all other thatn specifiec columns
          } else if (capabilityWall[2] == "1") {
            //user has specified accesss with 1strickes ===['clientFlag','*']
            if (rolesWall.includes(schemaColumn)) {
              //excludes specifed columns
              _rolesColumn(_col);
            } else {
              continue;
            } //gives all other thatn specifiec columns
          } else {
            continue;
          }
        } catch {}
      }
    } //grab the actions and it's permissions (create,update,delete) as label
    _tableColumn.push({
      name: "actions",
      schema: { type: "String" },
      label: "actions",
      value: capabilityWall[0] + capabilityWall[1] + capabilityWall[2],
    });
    _visibleColsName.push("actions");
    // _this_Defaulting();
    _setDefaults();
    visibleColumn(_visibleColsName);
    //
    _this_foreignDefault();
    return _tableColumn;
  }
});
watch(columns, (_nowRows, ov) => {
  return true;
}); // let _initCol = columns.value

async function _setDefaults() {
  // _this_modelOneModels = ['phone',"userName","geolocation",'location','phoneCode'] //
  _thisModels = [
    "phone",
    "userName",
    "geolocation",
    "location",
    "userID",
    "phoneCode",
  ]; //
  _thisDefault.value = await _this_Defaulting(_thisModels);
  _thisDefault.value["quantity"] = 1;
  _thisDefault.value["userID"] = Objprops._profile.id;
  //------==== building columns of thisMoel
  return true;
}

async function _this_foreignDefault() {
  //-------<<<<>>>>-------Preparing this_model role_schemas
  _this_modelOneSchema.value["time"] = { default: "" };
  _this_modelOneSchema.value["action"] = { default: "" };
  let _defaulting_client = await foreign_Columns(
    _this_modelOneSchema.value,
    invisibleColumns_client.value
  );
  _this_modelOneColumns.value = _defaulting_client[0];
  visibleColumns_client.value = _defaulting_client[1];
  await _clientDefaults(_defaulting_client[1]);

  //--------------------------------
  return false;
}

async function _clientDefaults(_this_modelOneModels) {
  _thisDefault_client.value = await _this_foreignDefaulting(
    _this_modelOneModels
  );
  _thisDefault_client.value["orderID"] = await _genOrderID();
  _thisDefault_client.value["userID"] = Objprops._profile.id;
  _thisDefault_client.value["quantity"] = 1;
  _thisDefault_client.value["served"] = "Requesting";
  _thisDefault_client.value["price"] = 0;
  //-------------------------(Defined Schema-1)
  return true;
}

//==========================================DEfaulting && Scheam Generations====End
///======

//---------form Validation_Rules
//===============================================-----------------------------------
//-----------------------DATAs ROWs--------------
// let _contentingliveStatus=ref(20000)
//-----------------------Secondary DATAs ROWs--------------
//--------------------------
//--------------------------------ROWS_SCHEMATIC FORMS

const pageSize = 50;
let pagination = ref({
  page: 1,
  rowsPerPage: 10,
  rowsNumber: 0,
});
async function onRequest() {
  pagination.value.rowsPerPage = 10;
  pagination.value.rowsNumber = 10;
  return true;
}

// _this_Query.value = {}; //_trend:'', catagory:'',usage:'New',content:''

//===============================QUERY_BUILDIMG+++START
//==============Q1

//==============Q1
async function _this_modelOneQuery() {
  //-------------------- Reseting Rows
  set_this_foreign(null, null);
  // __this_foreignBoxIndex.value = null;
  // __this_foreignBoxOpsStatus.value = true;
  // _this_modelOneRows.value = []; //mean waiting result
  // _clientQuery.value={}
  //---------Query Building
  //Content Owner is on client_link(show all)
  // if (!_is_modelOneOwner.value) {
  //   _modelOneQuery.value["userID"] = Objprops._profile.id;
  // }
  _modelOneQuery.value["userID"] = Objprops._profile.id;
  // _modelOneQuery.value["saleitID"] = _this.value["id"] ?? "";
  // _modelOneQuery.value["store"] = "buy";
  //-------------------- Fetching Queried Rows
  // _this_modelOneRows_Sync();
  // let _rows = await Fetch_this(modelOneService, _modelOneQuery.value);
  // if (_rows) {
  //   // _this_modelOneRows.value = _rows;
  // }
  // await Sync_this(modelOneService, _modelOneQuery.value);
  let _rows = await Fetch_this(modelOneService, _modelOneQuery.value);
  if (_rows) {
    _this_modelOneRows.value = _rows;
  }
  //-------------------- Preparing Default Rows ( New Row Skeltons)
  _this_modelOneforeign.value = Object.assign({}, _thisDefault_client.value);
  // _this_modelOneforeign.value['saleitID']=_this.value['id']  //----------- contentIDs
  _this_modelOneforeign.value["orderID"] = await _genOrderID();
  return true;
}
//==============Q3

let _orderBox = ref([]);
//---------------ACTIVE Operating on Row
//Operating without setting onplayrowItem ( directlly calling for effect) === active _operations
//__this_foreignBoxsubOps
const isRowDoublePressed = async function (_thisindex, _thisOps) {
  let _existed_this = __thisIndex.value == _thisindex;
  if (
    _thisindex == null ||
    (_existed_this && __this_foreignBoxOps.value == _thisOps)
  ) {
    _resetBoth(_thisOps, _thisModelService);
    return true;
  } else {
    return false;
  }
};
const isForeignDoublePressed = async function (
  _foreignindex,
  _foreignOps,
  _thisOps
) {
  let _existed_this = __this_foreignBoxIndex.value == _foreignindex;
  if (
    _foreignindex == null ||
    (_existed_this && __this_foreignBoxsubOps.value == _foreignOps)
  ) {
    _resetBoth(_thisOps, _thisModelService);
    return true;
  } else {
    return false;
  }
};

__this_foreignBoxOps.value = "clients";
//------operations OVer POP_Up_Box
let _this_foreignOperation = {
  //--------------------------
  _add: async () => {
    //default_value for sideBox
    __this_foreignBoxIndex.value = null;
    _this_modelOneforeign.value = Object.assign({}, _thisDefault_client.value);
    return true;
  },
  //---Enabling Array_Index_For Operations (Select_Index)_For ---Editing:Deleting--Applying--
  selectedIndex_: async (
    _foreignIndex = null,
    foreignSuboperation = null,
    foreignOps = null
  ) => {
    //---------- IS Duplicated Actions
    if (
      await isForeignDoublePressed(
        _foreignIndex,
        foreignSuboperation,
        foreignOps
      )
    )
      return false;
    //---------- IS Duplicated Actions
    // await set_this('clients',__thisIndex.value);
    await set_this_foreign(foreignOps, _foreignIndex);
    //---
    __this_foreignBoxIndex.value = _foreignIndex;
    __this_foreignBoxsubOps.value = foreignSuboperation;
    __this_foreignBoxOps.value = foreignOps;
    //----Defaulting foreign Links for main
    return true;
  },
  //---Enabling Array_Index_For Operations (Select_Index)_For ---Editing:Deleting--Applying--
  selectedIndex_RowDetail: async (
    _thisID,
    _foreignIndex = null,
    foreignSuboperation = null
  ) => {
    //---------- IS Duplicated Actions
    if (
      await isForeignDoublePressed(
        _foreignIndex,
        foreignSuboperation,
        "clients"
      )
    )
      return false;
    //---------- IS Duplicated Actions
    // alert(_foreignIndex)

    // __thisIndex.value = 0
    await Fetch_this(_thisModelService, { id: _thisID }).then(async (res) => {
      if (res) {
        _this_Rows.value = res; //[__thisIndex.value];
        await set_this("clients", 0);
        await set_this_foreign("clients", _foreignIndex);
      } else {
      }
    });
    __this_foreignBoxIndex.value = _foreignIndex;
    __this_foreignBoxsubOps.value = foreignSuboperation;
    //----Defaulting foreign Links for main
    return true;
  },

  //-----------Operations on selected array
  //-----------Operations on selected array
  _remove: async () => {
    if (__this_foreignBoxOps.value == "comments") {
      let fthis = { id: _this.value["id"], comments: _this_chatforeign.value };
      fthis["onplayOps"] = __this_foreignBoxOps.value;
      fthis["onplaySubops"] = "delete";

      let _chatResp = await modelTwoService.deleteData(fthis, {}); //[0],[1]
      if (!_chatResp.status) {
        timerError(500, "Error Creating", "");
        return false;
      }
      timerDone(5000, "Removed", "");

      //----updating saleitcontent
      _this_Rows.value[__thisIndex.value] = _chatResp.data.data;
      _this_modelTwoRows.value.splice(__this_foreignBoxIndex.value, 1);
      //----updating saleitcontent
      // set_this("comments", __thisIndex.value);
      set_this_foreign("comments", null);
    } else {
      let fthis = {
        id: _this.value["id"],
        clients: _this_modelOneforeign.value,
      };
      fthis["onplayOps"] = __this_foreignBoxOps.value;
      fthis["onplaySubops"] = "delete";

      let _clientResp = await modelOneService.deleteData(fthis); //[0],[1]

      if (!_clientResp.status) {
        timerError(500, "Error Creating", "");
        return false;
      }
      timerDone(5000, "Removed", "");

      //----updating foreign content
      _this_Rows.value[__thisIndex.value] = _clientResp.data.data;
      _this_modelOneRows.value.splice(__this_foreignBoxIndex.value, 1);
      //----updating saleitcontent
      //  _resetBoth("clients",null)
      set_this_foreign("clients", null);
    }

    return true;
  },
  _update_foreign: async () => {
    if (__this_foreignBoxOps.value == "comments") {
      let fthis = { id: _this.value["id"], comments: _this_chatforeign.value };
      fthis["onplayOps"] = "comments";
      fthis["onplaySubops"] = "update";

      let _chatResp = await modelTwoService.updateData(fthis, {}); //[0],[1]
      if (!_chatResp.status) {
        timerError(500, "Error Updating", "");
        return false;
      }
      timerDone(5000, "updated", "");

      _this_Rows.value[__thisIndex.value] = _chatResp.data.data;
      set_this("comments", __thisIndex.value);
      await _this_modelTwoQuery();
      //----updating saleitcontent
      // _this_Rows.value[__thisIndex.value] =_chatResp.data
    } else {
      let fthis = {
        id: _this.value["id"],
        clients: _this_modelOneforeign.value,
      };
      fthis["onplayOps"] = __this_foreignBoxOps.value;
      fthis["onplaySubops"] = "update";

      let _clientResp = await modelOneService.updateData(fthis, {}); //[0],[1]

      if (!_clientResp.status) {
        timerError(500, "Error Updating", "");
        return false;
      }
      timerDone(5000, "updated", "");

      _orderBox.value.push(_clientResp.data.data["id"] ?? null);
      _this_Rows.value[__thisIndex.value] = _clientResp.data.data;

      set_this("clients", __thisIndex.value);
      await _this_modelOneQuery();
      //----updating saleitcontent
      // _this_Rows.value[__thisIndex.value] =_clientResp.data
    }

    return true;
  },
  _create_foreign: async () => {
    if (__this_foreignBoxOps.value == "comments") {
      // _this_chatforeign.value['saleitID'] = _this.value['id']
      // _this_chatforeign.value['userID'] = Objprops._profile.id
      let fthis = { id: _this.value["id"], comments: _this_chatforeign.value };
      fthis["onplayOps"] = "comments";
      fthis["onplaySubops"] = "create";

      let _chatResp = await modelTwoService.createData(fthis, {}); //[0],[1]
      if (!_chatResp.status) {
        timerError(500, "Error Creating", "");
        return false;
      }
      timerDone(5000, "Created", "");

      _this_Rows.value[__thisIndex.value] = _chatResp.data.data;

      set_this("clients", __thisIndex.value);
      await _this_modelTwoQuery();
      //----updating saleitcontent
      // _this_Rows.value[__thisIndex.value] =_chatResp.data
    } else {
      // _this_modelOneforeign.value['saleitID'] = _this.value['id']
      // _this_modelOneforeign.value['userID'] = Objprops._profile.id
      let a = { id: _this.value["id"], clients: _this_modelOneforeign.value };
      a["clients"]["store"] = "buy";

      a["onplayOps"] = __this_foreignBoxOps.value;
      a["onplaySubops"] = "create";

      let _clientResp = await modelOneService.createData(a, {}); //[0],[1]
      if (!_clientResp.status) {
        timerError(500, "Error Creating", "");
        return false;
      }
      timerDone(5000, "Ordered", "");

      _orderBox.value.push(_clientResp.data.data["id"] ?? null);
      _this_Rows.value[__thisIndex.value] = _clientResp.data.data;

      set_this("clients", __thisIndex.value);
      await _this_modelOneQuery();
      //----updating saleitcontent
    }

    return true;
  },
  //------special Operations=========
  _newbuyer_foreign: async (_store = "buy", _isnewBuyer = true) => {
    // _this_modelOneforeign.value['saleitID'] = _this.value['id']
    // _this_modelOneforeign.value['userID'] = Objprops._profile.id
    let fthis = { id: _this.value["id"], clients: _this_modelOneforeign.value };
    fthis["clients"]["store"] = _store;

    // fthis["onplayOps"] = __this_foreignBoxOps.value;
    // fthis["onplaySubops"] = "create";
    let _clientResp;
    if (_isnewBuyer) {
      _clientResp = await modelOneService.createData(fthis, {});
    } else {
      _clientResp = await modelOneService.updateData(fthis, {}); //[0],[1]
    }

    if (!_clientResp.status) {
      timerError(500, "Error Creating", "");
      return false;
    }
    timerDone(5000, _store == "buy" ? "Ordered" : "ADD To Cart", "");

    _orderBox.value.push(_clientResp.data.data["id"] ?? null);

    _this_Rows.value[__thisIndex.value] = _clientResp.data.data;
    set_this("clients", __thisIndex.value);
    await _this_modelOneQuery();
    return true;
  },
};

let _this_ActiveOperation = {
  _detailView: async (_thisindex = null, _foreignIndex = null) => {
    //---------- IS Duplicated Actions
    // if(await ifRowDoublePressed(_thisindex,_thisOps)) return false
    //---------- IS Duplicated Actions
    //  _this_clientQuery()
    __thissubOps.value = _thissubOps;
    if (["details", "buy"].includes(__thissubOps.value)) {
    } else {
      _setthis_Resetforeign(_thisOps, _thisindex, null, _thisModelService);
      __thissubOpsStatus.value = false;
      return true;
    }
    __thissubOpsStatus.value = true;
    //----------------------------------
    await Fetch_this(_thisModelService, { id: _thisid }).then((res) => {
      if (res) {
        _setthis_Resetforeign(_thisOps, _thisindex, null, _thisModelService);
        __this_foreignBoxsubOps.value = "view";
        _this.value = res[0];
      }
    });
    return true;
  },
  selectedRow_ForeignRows: async (_thisindex = null, _thisOps = null) => {
    //---------- IS Duplicated Actions
    if (await isRowDoublePressed(_thisindex, _thisOps)) return false;
    //---------- IS Duplicated Actions

    _thisModelService.set_syncLock(true);
    await set_this(null, _thisindex);

    _thisOps == "clients"
      ? await _this_modelOneQuery()
      : await _this_modelTwoQuery();
    return true;
  },
  //===================
  _rating: async (_onplayrowIndex) => {
    //build dynamic object
    _this.value = {
      id: _this_Rows.value[_onplayrowIndex]["id"],
      _itServiceRating: _this_Rows.value[_onplayrowIndex]["_itServiceRating"],
    }; //DeepCopy Handle Reactivity

    //create object operational command
    _this.value["onplayOps"] = "_itServiceRating";
    _this.value["onplaySubops"] = "increase";
    //---set--loading row operation
    return await Crud_this.updateData()
      .then(async (response) => {
        console.log(response, "Rating....");
        if (response) {
          timerDone(5000, "You Rated", "Succefully Updated");
          _this_Rows.value[__thisIndex.value]["_itServiceRating"]++;
        } else {
          // timerDone(5000, "Connection Error", "Failed to connect");
        }
        return true;
      })
      .catch((error) => {
        return false;
      });
  },

  _likes: async (_onplayrowIndex) => {
    //build dynamic object
    _this.value = { id: _this_Rows.value[_onplayrowIndex]["id"] }; //DeepCopy Handle Reactivity
    //create object operational command
    _this.value["onplayOps"] = "likes";
    _this.value["onplaySubops"] = "increase";
    //---set--loading row operation

    return await Crud_this.updateData()
      .then(async (response) => {
        if (response) {
          timerDone(5000, "You Liked", "Succefully Updated");
          _this_Rows.value[_onplayrowIndex]["likes"]["like"]++; // =Object.assign({},response);
        } else {
          // timerDone(5000, "Connection Error", "Failed to connect");
        }
        return true;
      })
      .catch((error) => {
        return false;
      });
  },
  _following: async (_onplayrowIndex) => {
    //build dynamic object
    _this.value = { id: _this_Rows.value[_onplayrowIndex]["id"] }; //DeepCopy Handle Reactivity
    //create object operational command
    _this.value["onplayOps"] = "following";
    _this.value["onplaySubops"] = "increase";
    //---set--loading row operation

    return await Crud_this.updateData()
      .then(async (response) => {
        if (response) {
          timerDone(5000, "You Following", "Succefully Updated");
          // Objprops._profile.contacts.push(response.data)
          // _this_Rows.value[_onplayrowIndex]["likes"]["like"]++; // =Object.assign({},response);
        } else {
          // timerDone(5000, "Connection Error", "Failed to connect");
        }
        return true;
      })
      .catch((error) => {
        return false;
      });
  },
  _delRow: async (confirm = null, _onplayrowIndex, itemId) => {
    //--------------
    if (confirm == null) {
      //First (Null) Event -- Data Assigning && set confirmObj
      //-----------------------------
      _this.value = { id: itemId };
      // __thisIndex.value = _onplayrowIndex
      //--------------
      confirmObj.value = _this_ActiveOperation._delRow; //it carry the _delRow(,,,)... on button response it comes as
      //  _delRow(true/false)..parameter order is mattter.
      return false;
    } else {
      confirmObj.value = null;
      if (!confirm) {
        return false;
      } //Third (True) Event -- Go ahead or false(closed popup)
    }
    //--------waite for confirmation
    return await Crud_this.deleteData()
      .then((response) => {
        if (response) {
          this_Query("userID", Objprops._profile.id);
          // _this_Row.splice(__thisIndex.value,1)
        }
        return true;
      })
      .catch((error) => {
        return false;
      });
  },
  //------------special Operations
  _toCart: async (tocartID = null) => {
    _this.value = {
      id: tocartID,
      clients: Object.assign({}, _thisDefault_client.value ?? {}),
    }; //.push(_onplay); //or use below
    _this.value["clients"]["store"] = "cart";

    _this.value["onplayOps"] = "clients";
    _this.value["onplaySubops"] = "create";

    let _clientResp = await modelOneService.createData(_this.value, {}); //[0],[1]
    // console.log('creating client',_clientResp,_this.value,_this_modelOneforeign.value)
    if (!_clientResp.status) {
      timerError(500, "Error Creating", "");
      return false;
    }

    timerDone(5000, "Added", "");
    _orderBox.value.push(_clientResp.data.data["id"] ?? null);
    await _this_modelOneQuery();
    //----updating saleitcontent
    _this_Rows.value[__thisIndex.value] = _clientResp.data.data;
    return true;
  },

  //------------special Operations
};
//------------------

//--------------------------------------METHODS & PROCESS
async function _thisValidator(formtype) {
  let _isCompleted = Object.values(_debugObj.value).every(
    (value) => value == null
  );
  if (!_isCompleted) {
    return false;
  }
  //-----
  formtype == "Create_this" ? Create_this() : Update_this();
  return true;
}

async function Create_this() {
  //UpdateRowItem User DAta with no graphic to update
  //---set--loading row operation
  __thisOpsStatus.value = true;
  //is File Encapsulated ( if so ) ... extract the file by choosing ( either it was from folder or from camera_directlly )
  let _fileExistance = _fileAttributeName.value ?? false;
  if (_fileExistance) {
    //_this.value['file_']={'files':_fileExistance}
    _this.value[_fileExistance] = _fileAsRaw.value;
    if (typeof _fileAsRaw.value == "object") {
      _this.value["file_"] = { files: _fileExistance };
    } else {
      _this.value["file_"] = { file: _fileExistance };
    }
  }
  //--------set Operational parameters
  _this.value["onplayOps"] = "CreateRowItem";
  _this.value["onplaySubops"] = "new";
  //---Creat the Content... which is with/out of file encapsulations
  return await Crud_this.createData()
    .then(async (response) => {
      timerLoadevent({ createData: 1 }, 1, "Updating...");
      if (response) {
        timerDone(5000, "Item Created", "Succefully Created");
        __thisBox.value = false;
        return this_Query("id", Objprops._profile.id);
      } else {
      }
      __thisOpsStatus.value = false;
      // _fileAttributeName.value=null;
      return true;
    })
    .catch((e) => {
      timerError(5000, "Error Creating", "Error Creating" + e);
      _fileAttributeName.value = null;
      __thisOpsStatus.value = false;
      __thisBox.value = false;
      return false;
    });
}

async function Update_this() {
  //UpdateRowItem User DAta with graphic to update or not
  //---set--loading row operation
  __thisOpsStatus.value = true;
  //-------------
  let _fileExistance = _fileAttributeName.value ?? false;
  if (_fileExistance) {
    //_this.value['file_']={'files':_fileExistance}
    _this.value[_fileExistance] = _fileAsRaw.value;
    if (typeof _fileAsRaw.value == "object") {
      _this.value["file_"] = { files: _fileExistance };
    } else {
      _this.value["file_"] = { file: _fileExistance };
    }
  }
  //----------set Operational parameters
  _this.value["onplayOps"] = "UpdateRowItem";
  _this.value["onplaySubops"] = "update";
  //--------
  return await Crud_this.updateData()
    .then(async (response) => {
      timerLoadevent({ updateData: 1 }, 1, "Updating...");
      if (response) {
        timerDone(5000, "Item Updated", "Succefully Updated");
        _this_Rows.value[__thisIndex.value] = Object.assign({}, response);
        __thisBox.value = false;
        this_Query("id", Objprops._profile.id);
      } else {
      }
      __thisOpsStatus.value = false;
      // _fileAttributeName.value=null;
      return true;
    })
    .catch((e) => {
      timerError(5000, "Error Updating", "Error Updating" + e);
      __thisOpsStatus.value = false;
      __thisBox.value = false;
      _fileAttributeName.value = null;
      return false;
    });
}

//==========================ROW Confirming &&& Submitting==============

//----=========================================================================---DATA ---/// ---ROW----CRUD
let createKey = "phone";
let updateKey = "id";
let delKey = "id";
//ModalCrudOps
const Crud_this = {
  createData: async function (objParam = {}) {
    //-------Check for Param_Requirents
    timerLoadevent({ createData: 0 }, 0, "Updating...");
    try {
      if (_this.value[createKey] == null) {
        return false;
      }
      //-----------Calling for Store Services  (_suburl, formData, objParam)
      return await _thisService
        .createData(_thisapiUrl, _this.value, objParam)
        .then((response) => {
          if (response[0]) {
            return response[1];
          } else {
            timerError(5000, "Error createData", "..." + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerError(5000, "Error createData", "..." + e);
          return false;
        });
    } catch (e) {
      timerError(5000, "Error createData", "..." + e);
      return false;
    }
  },
  //----------------------------------------------------------------
  updateData: async function (objParam = {}) {
    //-------Check for Param_Requirments
    timerLoadevent({ updateData: 0 }, 0, "Updating...");
    try {
      if (_this.value[updateKey] == null) {
        return false;
      }
      //-----------Calling for Store Services  (_suburl, formData, objParam)
      return await _thisService
        .updateData(_thisapiUrl, _this.value, objParam)
        .then((response) => {
          if (response.status) {
            return response.data;
          } else {
            timerError(5000, "", "Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerError(5000, "Item Updated", "Succefully Updated" + e);
          return false;
        });
    } catch (e) {
      timerError(5000, "Error updateData", "..." + e);
      return false;
    }
  },

  readData: async function () {
    timerLoadevent({ readData: 0 }, 0, "Searching...");
    return await _thisService
      .readData(_thisapiUrl)
      .then((response) => {
        if (response.status) {
          return response.data;
        } else {
          timerError(5000, "", "Error" + response.data);
          return false;
        }
      })
      .catch((e) => {
        timerError(5000, "Error readData", "..." + e);
        return false;
      });
  },
  //---------------------------------------------------------------
  readFData: async function (objParam = {}) {
    //-------Check for Param_Requirents
    timerLoadevent({ readFData: 0 }, 0, "Searching...");
    try {
      if (Object.keys(objParam ?? {}).length == 0) {
        return false;
      }
      //-----------Calling for Store Services
      return await _thisService
        .readFData(_thisapiUrl, objParam)
        .then((response) => {
          if (response.status) {
            return response.data;
          } else {
            timerError(5000, "", "Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerError(5000, "Error readFData", "Succefully Updated" + e);
          return false;
        });
    } catch (e) {
      timerError(5000, "Error readFData", "..." + e);
      return false;
    }
  },

  deleteData: async function () {
    //-------Check for Param_Requirents
    timerLoadevent({ deleteData: 0 }, 0, "Searching...");
    try {
      if (_this.value[delKey] == null) {
        return false;
      }
      //-----------------
      let objParam = {};
      objParam[delKey] = _this.value[delKey];
      //---------
      return await _thisService
        .deleteData(_thisapiUrl, objParam)
        .then((response) => {
          if (response.status) {
            // timerDone(5000, 'Deleted', '...');
            return response.data;
          } else {
            timerError(5000, "", "Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerError(5000, "Error deleteData", "Succefully Updated" + e);
          return false;
        });
    } catch (e) {
      timerError(5000, "Error deleteData", "..." + e);
      return false;
    }
  },
  //------------------filtering & searching for different Model
};

let _contentingliveStatus = ref(250000);
const Sync_this = async (service, query) => {
  clearInterval(sync_thisInstante);
  await service.set_syncQuery(query);
  //-----Fetching Data ( Store_SyncFetch)
  service.set_syncLock(false);
  service.asyncDatas();
  //--------
  setTimeout(function () {
    clearInterval(sync_thisInstante);
    sync_thisInstante = setInterval(
      service.asyncDatas,
      _contentingliveStatus.value
    );
  }, 5000);

  return true;
};

const Fetch_this = async (service, query) => {
  return await service.readFData(query).then((res) => {
    if (res.status) {
      return res.data;
    }
    return false;
  });
};

// //--------------------
let _fileAsPath = ref(0); //_file in Show_Mode (As_String)
let _fileAsPathIndex = ref(null); //_fileAsPath_Array_index
let _fileAsPathSlide = ref(false);

let _fileAsPathOps = ref(false); //this is for selecting only

///_fileAsPathSlide
async function _fileAsPathOpsCall(StrIndex, index = null) {
  //calling for selections
  __thisIndex.value = index;
  //__this_foreignBoxOps.value=null
  _fileAsPathIndex.value = StrIndex;
  return true;
}

async function _fileAsPathSlideCall(_thisindex = null) {
  //calling for selections
  __thisIndex.value = _thisindex;
  //----------SET_ROW
  let _onplayRI = {};
  _onplayRI = _this_Rows.value[_thisindex]; //Object.assign({},_this_Rows.value[_thisindex])
  _this.value = Object.assign({}, _onplayRI); //DeepCopy Handle Reactivity
  //---------------
  _fileAsPathSlide.value = true;
  return true;
}

// var _cameraInstance = new _cameraDevice();
onMounted(() => {
  // clearInterval(sync_thisInstante);
  // modelOneService.set_syncLock(true);
  // modelTwoService.set_syncLock(true);
  // _thisModelService.set_syncLock(true);
  //-------
  _resetBoth();
});
// this_Query();
_this_modelOneQuery();
onUnmounted(async () => {
  // Clear the interval when the component is destroyed to avoid memory leaks
  // clearInterval(sync_thisInstante);
  modelOneService.set_syncLock(true);
  _thisModelService.set_syncLock(true);
  return true;
});
//----------------------------Utilities Funtions
</script>

<style>
/*=====================  Fronted_Glass / Blur Styles as OverLay Background... */
@keyframes myfirst /* Firefox */ {
  50% {
    opacity: 50;
  }
}
</style>
