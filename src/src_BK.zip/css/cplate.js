

export const cplate = ['red','blue','green','orange','black','white']



