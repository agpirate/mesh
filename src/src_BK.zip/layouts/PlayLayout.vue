<template>
  <q-dialog v-model="_Supports" class="column">
    <q-card v-if="customerSupport" class="fontbstyle flex column">
      <q-card-section>
        <div class="fontdstyle">Service Usage Manual</div>
      </q-card-section>

      <q-separator />

      <q-card-section style="max-height: 50vh; min-width: 20vw" class="scroll">
        <p v-for="n in 100" :key="n">
          {{ n }} Notices dslkff sodkfw pwef wp fpweof pefwepf pwope.
        </p>
      </q-card-section>

      <q-separator />

      <q-card-actions>
        <!--q-btn flat label="Decline" color="primary" v-close-popup /-->
        <q-btn flat label="Ok" color="primary" v-close-popup />
      </q-card-actions>
    </q-card>

    <q-card v-else-if="deviceSupport">
      Please Allow GPS && Camera Device, on Your Device
    </q-card>
  </q-dialog>

  <q-dialog v-model="_cameraBox" class="column overlay-Glass rounded-borders">
    <!--CameraFeeds  @Picture-taken="imageSrc = $event" / -->
    <div
      class="column"
      style="
        background-color: whitesmoke;
        border: 1px dashed #d6d6d6;
        border-radius: 4px;
        padding: 2px;
      "
    >
      {{ _this.geolocation ?? false }}
      <div v-if="_fileSourceFoCam == 'folder'"></div>
      <div v-else-if="_fileSourceFoCam == 'camera'">
        <div v-if="_thisMedia">
          <div class="col bg-white row fit">
            <video
              clas="col-2"
              ref="_liveFeedRawStreaming"
              autoplay
              playsinline
              style="width: 100%"
            ></video>
            <canvas
              id="_liveFeedSRC"
              ref="_liveFeedSRC"
              width="200px"
              height="200px"
              style="display: none"
            >
            </canvas>
            <q-list class="row q-gutter-xs">
              <q-item v-for="_src in _fileAsSRC" :key="_src">
                <q-img :src="_src" style="width: 100px; height: 100px" />
              </q-item>
            </q-list>
          </div>

          <div class="q-pa-sm q-gutter-sm row justify-between">
            <div>
              <q-btn
                rounded
                color="negative"
                size="sm"
                label="close"
                @click="_cameraInstance._stopCamera()"
              />
              <q-btn
                rounded
                color="green"
                size="sm"
                label="save"
                @click="_cameraInstance._saveScreenShoots()"
              />
              <q-btn
                rounded
                color="primary"
                size="sm"
                label="capture"
                icon="camera"
                @click="_cameraInstance._screenShoot()"
              />
            </div>

            <div size="col-auto row">
              <q-expansion-item
                switch-toggle-side
                expand-separator
                icon="camera"
                size="xs"
                v-if="_listCameraSource.length"
              >
                <q-item
                  v-for="camera in _listCameraSource"
                  :key="camera"
                  class="row q-gutter-sm"
                >
                  <q-btn
                    style="height: 100%"
                    no-caps
                    size="sm"
                    :dense="true"
                    :color="
                      _selectedCameraById == camera.deviceId ? 'blue' : 'black'
                    "
                    :label="camera.label ? camera.label.split('_')[1] : 'cam'"
                    @click="
                      _cameraInstance._setCameraParam(camera.deviceId, false)
                    "
                  />
                  <q-btn
                    style="height: 100%"
                    no-caps
                    size="sm"
                    :dense="true"
                    :color="
                      _selectedCameraById == camera.deviceId
                        ? 'orange'
                        : 'black'
                    "
                    :label="_selectedCameraByface ? 'Front Cam' : 'Back Cam'"
                    @click="
                      _cameraInstance._setCameraParam(
                        camera.deviceId,
                        !_selectedCameraByface
                      )
                    "
                  />
                </q-item>
              </q-expansion-item>
            </div>
            <!--div size="col-auto row"> {{  _listMicSource }}
                    <q-item v-for="mic in _listMicSource" :key=mic class="column">                                                     
                      <q-btn style="height:100%" no-caps size="sm" :dense="true" :color="_selectedMicById == mic.deviceId ? 'blue':'black'" :label="mic.label.split('_')[1]" @click="_cameraModule._selectedMicId(mic.deviceId)" />
                    </q-item>
                </div-->
          </div>
        </div>
        <div v-else class="col bg-white row fit">
          Error Connecting to Camera
        </div>
      </div>
      <div v-else>
        Error Accessing System, please allow on settting for Location and Media
        Devices
      </div>
    </div>
  </q-dialog>

  <!-- Debug Component and Mixing Values -->
  <!-----DEbug ( Action ) Informations-->
  <template v-if="DoneMessage.length ?? false">
    <debugCard :messages="DoneMessage ?? []" @closeButton="DoneMessage = []" />
  </template>
  <template v-if="WarnthisMessage.length ?? false">
    <debugCard :messages="WarnthisMessage ?? [{}]" />
  </template>
  <!-----Status ( Store/Loading ) Informations-->
  <!-- <template v-if="status_WarnthisMessage.length ?? false">
      <statusCard :messages="status_WarnthisMessage ?? [{}]" />
    </template>
    <template v-if="status_KnowthisMessage.length ?? false">
      <statusCard :messages="status_KnowthisMessage ?? [{}]" />
    </template>
    <template v-if="status_DoneMessage.length ?? false">
      <statusCard :messages="status_DoneMessage ?? [{}]" />
    </template> -->
  <!-- Debug Component and Mixing Values -->

  <div
    class="fixed-right z-top q-px-sm q-gutter-sm"
    style="top: 15vh; bottom: 55vh; max-height: 5vh"
  >
    <div class="row justify-end"></div>

    <q-card
      class="column q-gutter-sm q-pa-sm"
      v-if="_openpubChat"
      style="
        min-width: 5vw;
        min-height: 50vh;
        margin-bottom: 50px;
        background-color: whitesmoke;
      "
    >
      <div class="fontdstyle row justify-between">
        public Chatting
        <q-badge color="green" :dense="true" v-if="_chatWatch"> live</q-badge>
        <div>
          <q-toggle size="xs" v-model="_setpublicchat" val="xs" />
          <q-btn @click="_openpubChat = false" icon="close" flat />
        </div>
      </div>
      <div class="bg-white q-pa-sm">
        <label class="fontastyle">current session</label>
        <div><q-icon name="phone"> </q-icon> {{ _this.phone }}</div>
      </div>

      <q-card-section
        class="col-grow shadow-7 bg-white"
        style="max-height: 50vh; overflow-y: scroll"
      >
        <div
          v-for="(chats, index) in publicchatService.getDatas"
          class="q-gutter-xs column boxastyle q-my-sm"
          :key="index"
        >
          <div class="col-auto row fontastyle q-gutter-sm">
            <q-icon
              name="phone"
              style="background-color: white; border-radius: 50%"
            >
            </q-icon>
            <label class="q-ma-none"> {{ chats.phone }} </label>
          </div>
          <div class="col-grow fontbstyle">{{ chats.content }}</div>
        </div>
      </q-card-section>

      <div class="col-auto row q-pa-xs q-gutter-xs bg-white">
        <q-input outlined :dense="true" size="sm" v-model="_chatting.content">
        </q-input>
        <q-btn :dense="true" size="md" icon="send" @click="openpubChat()" />
      </div>
    </q-card>
  </div>
  <!-- Debug Component and Mixing Values -->
  <!-----DEbug ( Action ) Informations-->
  <template v-if="DoneMessage.length ?? false">
    <debugCard :messages="DoneMessage ?? []" @closeButton="DoneMessage = []" />
  </template>
  <template v-if="WarnthisMessage.length ?? false">
    <debugCard :messages="WarnthisMessage ?? [{}]" />
  </template>
  <!-----Status ( Store/Loading ) Informations-->
  <div
    v-if="Loading.length ?? false"
    class="fixed-bottom-right q-pa-md z-top q-gutter-sm column fontestyle"
  >
    <div class="fit bg-orange text-bold text-white">
      {{ Loading[0].content }}
    </div>
  </div>

  <!-- Debug Component and Mixing Values -->

  <!--walls-->
  <!--layOuts-->
  <div
    class="fixed fit column"
    style="background-repeat: no-repeat; background-size: cover"
    :style="{ 'background-image': 'url(' + _this['cover'] ?? 'white' + ')' }"
  >
    <div class="col-grow layout-Glass"></div>
  </div>

  <q-layout v-if="Loadingevent.main ?? false" class="column">
    <div class="fit bg-orange text-bold text-white">
      <!-- {{ Loadingpage.content ?? "..." }} -->
      Loading...
    </div>
  </q-layout>

  <q-layout
    v-else
    view="hHh lpr lFF"
    class="no-padding no-margine"
    style="max-width: 100svw; height: 100svh"
  >
    <!--Headers-->
    <q-header
      v-if="!isScrolledUp"
      :dense="true"
      id="navbar"
      elevated
      style="min-height: 30px"
      class="transparent"
    >
      <!--toolBars-->
      <q-toolbar
        class=" "
        v-if="$q.screen.lt.md ? true : false"
        style="backdrop-filter: blur(500px)"
      >
        <q-btn
          flat
          densebg-white
          round
          color="white"
          size="xs"
          @click="leftDrawerOpen = !leftDrawerOpen"
          aria-label="Menu"
          icon="menu"
        />

        <q-space />

        <div
          class="boxastyle row items-center"
          style="width: 60vw; height: 40px; border-radius: 12px"
        >
          <q-icon
            name="clear"
            color="red"
            class="col-auto cursor-pointer q-pa-xs"
            size="xs"
          />
          <input
            class="col font0astyle"
            type="text"
            placeholder="search"
            style="border-radius: 12px; height: 100%; border: 1px solid white"
          />
        </div>

        <!-- <q-input
          outlined
          :dense="true"
          size="xs"
          class="bg-white"
          style="border-radius:10px"
          color="white"
          v-model="lytSearchRow"
          placeholder="Search"
        >
          <template v-slot:prepend>
            <q-icon name="clear" class="cursor-pointer" size="xs" />
          </template>
        </q-input> -->
        <!--upload Button-->
        <!---service Choosing Ddowns-->

        <q-space />

        <q-btn
          flat
          dense
          no-wrap
          @click="
            lytCreatRow = lytCreatRow == 'Create0' ? 'Create1' : 'Create0'
          "
          icon="upload"
          no-caps
          class="q-ml-sm q-px-md fontastyle text-white"
          style="background-color: rgb(255, 81, 0)"
        >
        </q-btn>
      </q-toolbar>

      <q-toolbar class="fontastyle" style="backdrop-filter: blur(500px)" v-else>
        <q-btn
          flat
          dense
          round
          @click="leftDrawerOpen = !leftDrawerOpen"
          aria-label="Menu"
          icon="menu"
        />

        <!-- <label>saleIt </label>  -->
        <div class="q-gutter-xs row">
          <q-btn
            :dense="true"
            :icon="iservice.icon"
            flat
            stack
            no-caps
            class="row"
            :style="
              _pageSettings['path'] == iservice.path
                ? 'color:orangered'
                : 'color:black'
            "
            v-for="(iservice, key) in iservicei_Menu"
            :key="key"
            @click="routeIt(iservice.path)"
            >{{ key }}
            <q-tooltip
              style="background-color: black; color: white; font-weight: bolder"
            >
              {{ iservice.title }}
            </q-tooltip>
          </q-btn>
        </div>

        <!--div v-if="_profile_iss?.['group'] ?? false "> 
              <q-btn  @click="popUpgrader = !popUpgrader" flat no-caps  v-if="_profile_iss['group'] == 'client'" class="fontastyle" >   
                 <q-item-label> UpgradeMe </q-item-label>           
               </q-btn>               
               <q-btn v-else class="lt-sm"> Create</q-btn>
        </div-->

        <q-space />

        <!--- Searching/filtering Service-->
        <q-btn-dropdown auto-close flat :dense="true" class="">
          <template v-slot:label>
            <div class="row">
              <div class="row justify-around items-center no-wrap q-px-sm">
                <q-icon name="filter" size="xs" />
              </div>
            </div>
          </template>

          <q-list class="fontastyle">
            <q-item aria-hidden="true">
              <q-item-section class="" style="font-size: 0.7rem"
                >Filter By</q-item-section
              >
            </q-item>

            <q-item class="column">
              <q-item-section></q-item-section>
              <q-item-section class="row"
                ><div>Price &gt;</div>
                <q-input style="width: 2vw"></q-input
              ></q-item-section>
              <q-item-section class="row"
                >Price &lt; <q-input></q-input
              ></q-item-section>
              <q-item-section class="row"
                >Price = <q-input></q-input>
              </q-item-section>
            </q-item>
          </q-list>
        </q-btn-dropdown>

        <q-input
          rounded
          :dense="true"
          class=""
          outlined
          color="orange"
          v-model="lytSearchRow"
          placeholder="Search"
        >
          <template v-slot:prepend>
            <q-icon
              color="red"
              name="clear"
              class="cursor-pointer"
              size="xs"
              @click="lytSearchRow = ''"
            />
          </template>
        </q-input>
        <!--upload Button-->
        <!---service Choosing Ddowns-->
        <q-btn-dropdown auto-close flat class="">
          <template v-slot:label>
            <div class="row q-px-sm">
              <div class="row justify-around items-center no-wrap q-px-sm">
                <q-icon name="add" size="xs" />
              </div>
              <div
                class="row items-center no-wrap"
                style="text-transform: capitalize"
              >
                itServices
              </div>
            </div>
          </template>

          <q-list class="fontastyle">
            <q-item aria-hidden="true">
              <q-item-section class="" style="font-size: 0.7rem"
                >select service</q-item-section
              >
            </q-item>

            <q-item clickable @click="tab = 'Saleit'">
              <q-item-section>Sale Service</q-item-section>
            </q-item>

            <q-item clickable @click="tab = 'Rentit'">
              <q-item-section>Renting Service</q-item-section>
            </q-item>
            <q-separator inset />
            <q-item
              clickable
              @click="[_Supports, customerSupport] = [true, true]"
            >
              <q-item-section>How To Use ?</q-item-section>
            </q-item>

            <q-item-section>
              User Weight : {{ _this.queryWeight ?? "null" }}</q-item-section
            >
          </q-list>
        </q-btn-dropdown>

        <q-space />

        <q-btn
          flat
          dense
          no-wrap
          @click="
            lytCreatRow = lytCreatRow == 'Create0' ? 'Create1' : 'Create0'
          "
          icon="upload"
          no-caps
          label="Create Content"
          class="q-ml-sm q-px-md fontastyle text-white"
          style="background-color: rgb(255, 81, 0)"
        >
        </q-btn>
        <q-btn
          @click="openpubChat(true)"
          icon="chat"
          :dense="true"
          flat
          class="text-white"
          ><q-tooltip>Join Public Chats</q-tooltip>
        </q-btn>

        <div class="q-gutter-sm row items-center no-wrap">
          <q-item-label>
            {{ _this.userName }}
          </q-item-label>
          <!--q-btn round dense flat color="text-grey-7" icon="apps">
           <q-tooltip>itService Apps</q-tooltip>
         </q-btn-->

          <!--q-btn round dense flat color="grey-8" icon="notifications">
           <q-badge color="red" text-color="white" floating>
             2
           </q-badge>
           <q-tooltip>Notifications</q-tooltip>
         </q-btn-->
          <q-btn round flat @click="leftDrawerOpen = !leftDrawerOpen">
            <q-avatar>
              <img :src="_this.profile" />
            </q-avatar>
            <q-tooltip>{{ _this.name }}</q-tooltip>
          </q-btn>
        </div>
      </q-toolbar>
    </q-header>

    <!--drawer-Left-->

    <q-drawer
      v-model="leftDrawerOpen"
      bordered
      :breakpoint="0"
      side="left"
      overlay
      elevated
      class="row"
      style="height: 100%"
    >
      <div class="col" style="height: 100%; width: 100vw">
        <q-scroll-area class="column" style="height: 100%">
          <!----profile graphics/imaging-->
          <q-card class="fontastyle" flat bordered style="">
            <q-img
              :src="
                _fileAttributeName == 'cover'
                  ? _fileAsSRC[_fileAsSRCIndex]
                  : _this.cover ?? ''
              "
              class="column fontastyle"
              style="aspect-ratio: 2/1; width: 100%"
            >
            </q-img>

            <div
              style="position: absolute; top: 0px; height: 100%"
              class="column justify-between q-pa-sm"
            >
              <div class="transparent column items-start">
                <div class="row">
                  <q-btn
                    flat
                    icon="more_vert"
                    color="green"
                    label="Cover"
                    class="col-auto"
                    @click="_thisOps = 'covering'"
                  >
                    <q-menu
                      auto-close
                      :offset="[2, 2]"
                      class="q-pa-sm transparent"
                    >
                      <input
                        type="file"
                        ref="filec"
                        style="display: none"
                        @change="_fileSourceFolder($event, 'cover')"
                      />
                      <q-btn
                        icon="folder"
                        class="text-dark"
                        @click="$refs.filec.click()"
                        :dense="true"
                      />
                      <q-btn
                        icon="add_a_photo"
                        class="text-dark"
                        @click="_cameraInstance._openCamera('cover')"
                        :dense="true"
                      />
                    </q-menu>
                  </q-btn>
                </div>
              </div>

              <div
                class=""
                style="width: 5em; height: 5em; border-radius: 0.6rem"
                v-if="_this?.profile ?? false"
              >
                <q-img
                  :src="
                    _fileAttributeName == 'profile'
                      ? _fileAsSRC[_fileAsSRCIndex]
                      : _this.profile[_fileAsSRCIndex] ?? ''
                  "
                  class="fit"
                  style="border: 1px solid white; border-radius: 0.6rem"
                />
              </div>
            </div>
            <!---- for_Name -- -->
          </q-card>

          <q-card
            class="row justify-between items-center q-px-sm fontastyle"
            flat
            v-if="_thisOps ?? false"
          >
            <!---profile_update-->
            <div class="q-gutter-xs justify-end">
              <input
                type="file"
                multiple
                ref="filep"
                style="display: none"
                @change="_fileSourceFolder($event, 'profile')"
              />
              <q-btn
                icon="folder"
                class=""
                flat
                @click="$refs.filep.click()"
                :dense="true"
              />
              <q-btn
                color="grey-4"
                class=""
                flat
                text-color="purple"
                icon="camera"
                @click="_cameraInstance._openCamera('profile')"
                :dense="true"
              />
            </div>

            <div>
              <q-btn
                class="fontastyle bg-grey-3"
                icon="done"
                no-caps
                size="12px"
                flat
                :dense="true"
                @click="updateUser()"
              >
                Apply
              </q-btn>
            </div>
          </q-card>

          <!----profile basic informations-->
          <q-list padding class="col-9 column" style="min-height: 60vh">
            <q-item>
              <q-item-section>
                <q-item-label overline>{{ _this.username }}</q-item-label>
                <q-item-label
                  >{{ _this.name }} {{ _this.lastName }}</q-item-label
                >
                <!-- <q-item-label caption>Since : {{  _this.updatedAt }}</q-item-label> -->
              </q-item-section>

              <q-item-section side top>
                <q-item-label class="row justify-between fontastyle">
                  <q-btn
                    flat
                    class="fontastyle text-red"
                    round
                    label="Cancel"
                    :dense="true"
                    @click="_thisOps = _thisOps ? false : 'cinfo'"
                    v-if="_thisOps"
                  />
                  <div v-else>
                    <q-btn
                      flat
                      class="fontastyle text-orange"
                      :dense="true"
                      label="MyStore"
                    />
                    <q-btn
                      flat
                      class="fontastyle text-blue"
                      round
                      label="Edit Profile"
                      :dense="true"
                      @click="_thisOps = _thisOps ? false : 'cinfo'"
                    />
                  </div>
                </q-item-label>
              </q-item-section>
            </q-item>

            <q-separator spaced />
            <!----Personal Information  _thisOps -->

            <q-item
              v-for="cinfo in ['name', 'lastName', 'userName']"
              :key="cinfo"
            >
              <q-item-section>
                <q-item-label
                  style="text-transform: capitalize"
                  v-if="_thisOps == 'cinfo'"
                >
                  <q-input
                    standout
                    v-model="_this[cinfo]"
                    :label="cinfo"
                    stack-label
                    :dense="true"
                  />
                </q-item-label>
                <q-item-label style="text-transform: capitalize" v-else>
                  <q-input
                    standout
                    v-model="_this[cinfo]"
                    :label="cinfo"
                    stack-label
                    :dense="true"
                    readonly
                  />
                </q-item-label>
              </q-item-section>

              <q-item-section side>
                <div class="text-grey-8 q-gutter-xs" v-if="_thisOps == 'cinfo'">
                  <q-btn
                    class="gt-xs"
                    size="12px"
                    flat
                    dense
                    round
                    icon="clear"
                    @click="_this[cinfo] = ''"
                  />
                  <!-- <q-btn class="gt-xs" size="12px" flat dense round icon="done" @click="updateUser()" /> -->
                </div>
              </q-item-section>
            </q-item>

            <!------Address Informa-->
            <q-separator spaced inset="item" />
            <div class="col-auto q-px-sm row justify-between row">
              <div class="fontcstyle">Contacts</div>

              <q-item-label>
                <q-btn icon="add" :dense="true">Contact</q-btn>
                <!-- Incomplete Profile -->
                <q-tooltip style="background-color: black">
                  Add Contacts to follow</q-tooltip
                >
              </q-item-label>
            </div>
            <q-separator spaced inset="item" />
            <q-scroll-area class="col-grow column">
              <q-item class="col-grow column">
                <q-item-section
                  class="fontastyle"
                  v-for="(contact, index) in _this.contacts"
                  :key="index"
                >
                  <q-btn flat :dense="true" class="fontastyle text-bold"
                    >+{{ contact }}</q-btn
                  >
                </q-item-section>
              </q-item>
            </q-scroll-area>
          </q-list>

          <q-separator spaced inset="item" />
          <q-list class="col-2">
            <q-item class="items-center q-gutter-sm">
              <q-item-label> Language: </q-item-label>
              <q-item-label>
                <q-btn
                  :dense="true"
                  no-caps
                  class="q-pa-none"
                  flat
                  size="sm"
                  :label="_pageSettings.languageOptions[_pageSettings.language]"
                  @click="
                    _pageSettings.language = _pageSettings.language ? 0 : 1
                  "
                />
              </q-item-label>
            </q-item>

            <q-item class="row">
              <q-item-label
                class="col boxastyle q-pa-sm row justify-between bg-orange text-dark"
              >
                itService V0.1

                <q-item-label>&copy;2023 </q-item-label>
              </q-item-label>
            </q-item>
          </q-list>
          <!-- <q-badge
          v-if="_profile_iss != 'client'"
          class="justify-between q-pa-xs q-mx-md"
        >
          Upgraded</q-badge
        >
        <q-badge v-else class="justify-left q-mx-md" color="dark">
          <q-item-label style="color: red">Un Upgraded</q-item-label>
          <q-tooltip class="q-pa-xs"
            >Upgrading enables to sale and buy !</q-tooltip
          >
        </q-badge>
        <q-badge class="justify-between q-pa-xs q-mx-md"> </q-badge> -->
        </q-scroll-area>

        <!-- <div class="col-5 bg-green" @click="leftDrawerOpen = false">
        sssssssssssssssss
      </div> -->
      </div>
    </q-drawer>

    <!---drawer-Left-->
    <!-- :userID="_this.id"

            :userName="_this.userName"
            :phone="_this.phone"

            :phoneCode="_this.phoneCode"
            :location="_this.location"
            :geolocation="_this.geolocation" -->

    <q-page-container
      style=""
      class="col-grow transparent row"
      v-if="(_this['acctype'] ?? false) && (_this.id ?? false)"
    >
      <router-view
        :_profile="_this"
        :_acctype="_this.acctype ?? {}"
        :lytCreatRow="lytCreatRow"
        :lytSearchRow="lytSearchRow"
        :isScrolled="isScrolled"
        :isScrolledUp="isScrolledUp"
        :_thisMedia="_thisMedia"
        :_pageSetting="_pageSettings"
      />
    </q-page-container>
    <!--sticky_icons---inside-containers-->
    <div class="leftmidBox q-pa-none q-ma-none">
      <q-card
        class="q-py-xs column transparent fontastyle"
        style=""
        v-if="showsideMenu"
      >
        <!-- <q-btn flat icon="home" @click="router.push('/play/trend')" /> -->

        <q-separator inset horizontal />

        <q-btn
          :dense="true"
          size="sm"
          flat
          stack
          no-caps
          class="fontdstyle"
          @mouseover="iservice[3] = true"
          @mouseleave="iservice[3] = false"
          v-for="(iservice, index) in iservicei_Menu"
          :key="iservice"
          @click="routeIt(iservice.path)"
        >
          {{ index }} sss
          <!--q-item-label v-if="iservice[3]" caption >{{ iservice.title }} </q-item-label-->
          <q-icon size="xs" :name="iservice.icon" />
          <div>My</div>
        </q-btn>

        <q-btn
          flat
          label="?"
          @click="[_Supports, customerSupport] = [true, true]"
        />

        <q-separator inset horizontal />

        <!--q-btn  flat icon="more_vert"  @mouseover="showsideMenu =true">
      <q-menu auto-close :offset="[2, 2]"  self="bottom left">
        <q-list >
          <q-item clickable>
            <q-item-section>New group</q-item-section>
          </q-item>
          <q-item>
            <q-toggle
              size="xs"
              val="xs"
              toggle-indeterminate
              toggle-order="ft"
              v-model="toglColor"
              label="Mode"
              color="blue"
              :class="{
                'text-black ': $q.dark.isActive,
                'text-white': !$q.dark.isActive,
              }"
              @click="$q.dark.toggle()"
            />
 
          </q-item>
        </q-list>
      </q-menu>
    </q-btn-->
      </q-card>

      <!-- <q-btn  flat icon="more_vert"   @mouseover="showsideMenu = !showsideMenu" /> -->
    </div>

    <!--sticky-ends-->

    <!----Footers _null-->

    <q-footer
      class="col-auto row justify-evenly q-px-sm"
      style="background-color: whitesmoke"
      v-if="$q.screen.lt.sm ? true : false"
    >
      <!-- <market-value /> -->
      <div v-if="Loadingevent.main ?? false">
        <div
          :style="Loadingevent.main ? 'width:80%;background-color:orange' : ''"
        ></div>
      </div>
      <div
        v-for="(iservice, key) in iservicei_Menu"
        :key="key"
        class="col-grow q-pa-none q-ma-none"
      >
        <q-btn
          :dense="true"
          :icon="iservice.icon"
          flat
          stack
          no-caps
          class="row col-grow q-ma-none q-pa-none font0astyle text-black"
          @click="routeIt(iservice.path)"
        >
          {{ key }}
          <q-tooltip
            style="background-color: black; color: white; font-weight: bolder"
          >
            {{ iservice.title }}
          </q-tooltip>
        </q-btn>

        <div
          :class="_pageSettings.path == iservice.path ? 'horizontalLine ' : ''"
        ></div>
      </div>
    </q-footer>
  </q-layout>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onBeforeMount, watch } from "vue";
import { storeToRefs } from "pinia";
import { toRaw } from "vue";
import { useLocalStorage } from "@vueuse/core";
//import { notifyit } from "src/composables/transducer";
import { getCountry, getState, countries } from "src/services/geotimezone";

import { exportFile, useQuasar, useMeta } from "quasar";
import { screenSize } from "src/services/utils";
//import userProfile from "src/components/userProfile.vue"
import { timeStore } from "src/stores/jstStores/serviceStore.js";
import { useRouter } from "vue-router";

import { profileStore } from "src/stores/authenticatedStore/profileStore";
import { publicchatStore } from "src/stores/chatStores/publicchatStore";
//import {chatStore} from "src/stores/authenticatedStore/chatStore"
import { authenticatingStore } from "src/stores/authenticatedStore/authenticatingStore";

import _localStorage from "src/services/storeService";
//---
import { useScroll } from "@/composables/scrollEvent";
const { isScrolled, isScrolledUp } = useScroll(1000); // Adjust threshold as needed

// import _localStorage from "src/services/storeService"; //_localStorage._clear()
//var socket = new WebSocket('ws://127.0.0.1:9100');
import debugCard from "src/components/debugCards.vue";
import useDebugMixin from "src/composables/debugMixin";
const {
  Loading, //
  Loadingevent,

  DoneMessage,
  KnowthisMessage,
  WarnthisMessage,
  //----------returning values
  // timerLoadpage,
  timerLoadevent,

  timerLoad,

  timerDone,
  timerInformthis,
  timerError,
} = useDebugMixin();

import useStatusMixin from "@/composables/statusMixin";
const {
  status_Loading,
  status_DoneMessage,
  status_KnowthisMessage,
  status_WarnthisMessage,
  //----------returning values
  staus_timerLoad,
  status_timerDone,
  status_timerInformthis,
  status_timerError,
} = useStatusMixin();

import usefileMixin from "src/composables/fileserviceMixin";
var {
  _thisMedia,
  _fileAttributeName,
  //-------
  _cameraBox,
  _fileSourceFoCam,
  _fileAsSRC,
  _fileAsRaw,

  _liveFeedSRC,
  _fileAsSRCIndex,
  //---
  _cameraDevice,
  _listCameraSource,
  _selectedCameraById,
  _selectedCameraByface,
  _liveFeedRawStreaming,
  //--------
  _fileSourceFolder,
  //--------
  _fileAsSRCOps,
  _fileAsSRCOpsCall,
  //-----------
  _resetFileSource,
  //---
  // _resetfBox,
} = usefileMixin();

//--------------
const $q = useQuasar();
//-----------Store & Service

const profileService = profileStore();
const publicchatService = publicchatStore();
//-----------
const _theService = profileService;
const authService = authenticatingStore(); //it(storeToRefs) is like computed_ reactive_variable

const router = useRouter();

//const $m = useMeta()

const metaData = {
  // sets document title
  title: "iService",
  // optional; sets final title as "Index Page - My Website", useful for multiple level meta
  titleTemplate: (title) => `${title} - DashBoard`,

  icon: "/public/icons/favicon-32x32.jpg",
  // JS tags
  script: {
    printJs: {
      type: "application/ld+json",
      innerHTML: `{  }`,
    },
    ldJson: {
      type: "application/ld+json",
      innerHTML: `{ }`,
    },
  },
};

useMeta(metaData);
//--------------------
//$q.dark.toggle()
//-------
var lytSearchRow = ref("");

//------variables
var leftDrawerOpen = ref(false); //hide & show sideBar
var _popUpgrader = ref(false);

var _Supports = ref(false);
var customerSupports = ref(false);
var deviceSupport = ref(false);

var lytCreatRow = ref(false);
//import CameraFeeds from "components/CameraFeeds.vue"
// let _cameraBox =ref(false)
//lytCreatRow
//-----------------------Local Varialbles
var iservicei_Menu = ref();
var showsideMenu = ref(false);
iservicei_Menu.value = {
  Home: {
    content: "Shoping",
    icon: "home",
    title: "saleIt",
    checked: false,
    path: "saleit",
  },
  MyStore: {
    content: "what did i bought ?",
    icon: "shop",
    title: "Shop",
    checked: false,
    path: "saleitclient",
  },
  MyService: {
    content: "Shoping",
    icon: "store",
    title: "saleIt",
    checked: false,
    path: "store",
  },
};

//-----Layout_Style & behaviors
let _profile_iss = ref(null);
//-------------USER PROFILE_Variables..
//===============================================-----------------------------------------
//------------- MODAL ROWs_ MANAGMENT

var _this = ref({});
let _thisOps = ref(null); //the selected row_actual_Data..as object

async function _thisDefaulting() {
  _this.value = {};
  try {
    _this.value.phone = null;
    _this.value.phoneCode = ["", ""];

    _this.value.geolocation = {};
    _this.value.geolocation = { lat: "", long: "" };

    _this.value.location = {};
    _this.value.location = { country: "", city: "", street: "" };
  } catch {}

  return true;
}

//===============================================-----------------------
watch(_this, async (_newV, _oldV) => {
  let _requestHeader = {};
  let _geoLoc = _newV?.["geolocation"] ?? false;
  if (_geoLoc) {
    _updateStorage("lat", toRaw(_geoLoc.lat ?? null));
    _updateStorage("long", toRaw(_geoLoc.long ?? null));
  }
  //-----------
  try {
    _localStorage._set("currency", _newV.phoneCode[2] ?? null);
  } catch {}
  _setPageSetting();
  return true;
});

///-----------------------File Operations and setting  UP(Folder) vs Down(Camera)
//-------------------------------------------
//---------------Automatically register all visitors (Basic Infor...Phone_)
async function updateUser(_isFileCapsulated = false) {
  //updating User DAta with graphic to update
  //_thisOpsStatus.value=false
  let _fileExitance = _fileAttributeName.value ?? false;
  if (_fileExitance) {
    _this.value[_fileExitance] = _fileAsRaw.value;
    if (_fileExitance == "profile") {
      _this.value["file_"] = { files: _fileExitance }; //profile require multiple file
    } else {
      _this.value["file_"] = { file: _fileExitance }; //or cover it's (require single file)
    }
  }

  _fileAttributeName.value = null;
  return await Crud_this.updateData()
    .then((response) => {
      if (response) {
        _this.value = Object.assign(_this.value, response); //is creating error on _page(routerView)
        _thisOps.value = false;
        timerDone(5000, "Item Updated", "Succefully Updated");
      } else {
        timerError(5000, "Error Updating", "Error Updating" + response);
      }
      return true;
    })
    .catch((e) => {
      _thisOps.value = false;
      timerError(5000, "Error Updating", "Error Updating" + e);
      return false;
    });
}

//----------------
let createKey = "phone";
let updateKey = "id";
let delKey = "id";

//ModalCrudOps

const Crud_this = {
  createData: async function (objParam = {}) {
    //-------Check for Param_Requirents
    try {
      if (_this.value[createKey] == null) {
        return false;
      }
      //-----------Calling for Store Services  (_suburl, formData, objParam)
      return await _theService
        .createData(_this.value, objParam)
        .then((response) => {
          if (response.status) {
            return response.data;
          } else {
            timerLoadevent({ createData: 5000 }, 5000, "Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerLoadevent(
            { createData: 5000 },
            5000,
            "Error createData",
            "..." + e
          );
          return false;
        });
    } catch (e) {
      timerLoadevent({ createData: 5000 }, 5000, "Error createData", "..." + e);
      return false;
    }
  },
  //----------------------------------------------------------------
  updateData: async function (objParam = {}) {
    //-------Check for Param_Requirments
    try {
      if (_this.value[updateKey] == null) {
        return false;
      }
      //-----------Calling for Store Services
      return await _theService
        .updateData(_this.value, objParam)
        .then((response) => {
          if (response.status) {
            return response.data;
          } else {
            timerLoadevent({ updateData: 5000 }, 5000, "Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerLoadevent(
            { updateData: 5000 },
            5000,
            "Error updateData",
            "..." + e
          );
          return false;
        });
    } catch (e) {
      timerLoadevent({ updateData: 5000 }, 5000, "Error updateData", "..." + e);
      return false;
    }
  },

  readData: async function () {
    timerLoadevent({ readData: 0 }, 0, "Searching...");
    return await _theService
      .readData()
      .then((response) => {
        if (response.status) {
          return response.data;
        } else {
          timerLoadevent({ readData: 5000 }, 0, " Error " + response.data);
          return false;
        }
      })
      .catch((e) => {
        timerLoadevent({ readData: 5000 }, 5000, "Error Deleting", "..." + e);
        return false;
      });
  },

  //---------------------------------------------------------------
  readFData: async function (objParam = {}) {
    //-------Check for Param_Requirents
    timerLoadevent({ readFData: 0 }, 0, "Searching...");
    try {
      if (Object.keys(objParam).length == 0) {
        return false;
      }
      //-----------Calling for Store Services
      return await _theService
        .readFData(objParam)
        .then((response) => {
          if (response.status) {
            return response.data;
          } else {
            timerLoadevent({ readFData: 5000 }, 0, " Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerLoadevent(
            { readFData: 5000 },
            5000,
            "Error Deleting",
            "..." + e
          );
          return false;
        });
    } catch (e) {
      timerLoadevent({ readFData: 5000 }, 5000, "Error Deleting", "..." + e);
      return false;
    }
  },

  deleteData: async function () {
    //-------Check for Param_Requirents
    timerLoadevent({ deleteData: 0 }, 0, "Searching...");
    try {
      if (Object.keys(objParam).length == 0) {
        // notifyit.warn("Incompleted Form ?");
        return false;
      }
      //-----------------
      let objParam = {};
      objParam[delKey] = _this.value[delKey];
      //---------
      return await _theService
        .deleteData(objParam)
        .then((response) => {
          if (response.status) {
            // timerDone(5000, 'Deleted', '...');
            return response.data;
          } else {
            timerLoadevent({ deleteData: 5000 }, 0, " Error" + response.data);
            return false;
          }
        })
        .catch((e) => {
          timerLoadevent(
            { deleteData: 5000 },
            5000,
            "Error Deleting",
            "..." + e
          );
          return false;
        });
    } catch {
      timerLoadevent({ deleteData: 5000 }, 5000, "Error Deleting", "..." + e);
      return false;
    }

    return await _theService
      .deleteData(objParam)
      .then((response) => {
        if (response[0]) {
          return response[1];
        } else {
          // notifyit.warn("Store Return False" + response[1]);
          return false;
        }
      })
      .catch(() => {
        // notifyit.info("Try to reconnect...");
        return false;
      });
  },
};
//--------------------------------------------------------------------UTILITIED_FUNCTIONS ( LocalStarage -- Profiling)
//_____________________________________________________Functions Definitions

//-----------------------------------Loading...process...showOFF

let init_navObj = ref(false);
let _location = ref(null);
let _Country = ref([]); //computed(() => getCountry());
let _State = ref(null);
let askForGPS = ref(false);
var _thisPosition = function () {
  return {
    _init: async function () {
      navigator.permissions
        .query({ name: "geolocation" })
        .then(async function (permissionStatus) {
          if (permissionStatus.state === "granted") {
            positionInstance.allowGPS(true);
          } else {
            askForGPS.value = permissionStatus.state;
          }
        });
      console.error("=-----END GeoLocator INIT-----=");
      return true;
    },
    allowGPS: async function (allow = false) {
      askForGPS.value = false;
      if (!allow) {
        init_navObj.value = false;
        console.error("GeoLocation Access Call Blocked By User");
      } else {
        try {
          if (navigator.geolocation ?? false) {
            init_navObj.value = navigator.geolocation;
            setLocations(true);
          }
          console.error(init_navObj.value, "GeoLocation Access Call Result");
          return true;
        } catch (e) {
          console.error(e, "GeoLocation Access Call Error");
        }
      }
      setLocations(false);
      return false;
    },
    watchCurrentPosition: async function () {
      try {
        init_navObj.value.watchPosition(
          (geodata) => {
            var _geolat = parseFloat(geodata.coords.latitude ?? 0);
            var _geolong = parseFloat(geodata.coords.longitude ?? 0);
            if (_geolat && _geolat != _this.value.geolocation.lat) {
              _this.value.geolocation = { lat: _geolat, long: _geolong };
              // _location.value = { country:null, city: null, street: null };
            } else {
            }
            // console.error(
            //   "watchCurrentPosition()",
            //   _geolong,
            //   _geolat,
            //   " I S NEW =? ",
            //   _geolat != _this.value.geolocation.lat,
            //   "Final Value ==",
            //   _this.value.geolocation
            // );
            return this;
          },
          (e) => {
            console.error(e, "CurrentPosition Watch GPS Error");
            return this;
          },
          {
            enableHighAccuracy: true,
            timeout: 100 * 60 * 24,
            maximumAge: 60000,
          }
        );
      } catch (e) {
        console.error(e, "CurrentPosition Watch GPS Error");
        return false;
      }
    },
    getCurrentPosition: async function () {
      // Access geolocation
      init_navObj.value.getCurrentPosition(
        (position) => console.log(position),
        (error) => console.error(error)
      );
    },
  };
};

async function setLocations(dynamic = false) {
  //------if GPS allowed activate it first
  if (dynamic) await positionInstance.watchCurrentPosition();
  //extract geoData
  //extract geoData
  console.log(
    "Setting Locations =<> GPS = ",
    Object.values(_this.value.geolocation ?? {}),
    " && timeZone = ",
    _State.value
  );
  if (!_State.value) {
    return false;
  }
  //---------------
  //------ If GPS is Active(GOOD), Else use the timezone GPSLocation
  if (!(_this.value.geolocation.lat ?? false)) {
    let geoLoc = (_State.value.loc ?? "").split(",");
    console.error(geoLoc, "GPS ACESS IS BLOCKED, timeZone API OPtions ....");
    if (geoLoc[1]) {
      _this.value.geolocation = { lat: geoLoc[0], long: geoLoc[1] };
    }
  }
  //always use the timezone/apitime zone data to locationsInformations
  _this.value.phoneCode = _Country.value;
  _this.value.location["country"] = _State.value.country ?? ""; //
  _this.value.location["city"] = _State.value.city ?? ""; //
  _this.value.location["street"] = _State.value.city ?? ""; //
  _this.value.location["provinance"] = _State.value.region ?? ""; //

  //---------------------- for product tracking purpose only
  _this.value.currency = _Country.value[2]; //
  //-------------

  //---------
  console.log(
    "Final =<> GPS = ",
    _this.value.geolocation,
    " && Locations = ",
    _this.value.location,
    " && contry Code ==",
    _Country.value
  );
  return true;
}
//-----------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@---- authentication Auditors and Setup
var { getLogStatus, getLogUser, getLogisREgistered, clearlogStatus } =
  storeToRefs(authService); //is like making reactive(ref)_variable
watch(getLogisREgistered, async (_newV, _oldV) => {
  if (_newV) console.log("user Loged");
  return true;
});
//--------------------------------------------------------------------Profiling (CHECK AUTHENTICATIONS &&& USER INFORMATIONS)
var _manageStoreLogin = async function () {
  console.log(
    "\n\nFunction - _manageStoreLogin --STORE Authentication Initializing [Phone,Stored_ID]---- \n"
  );
  return await authService
    .useLogin(_this.value)
    .then(async (resp) => {
      console.log(`\n LoginStatus = ${resp.status} \n`);
      if (!(resp.status ?? false) || !(resp["data"] ?? false)) {
        //------------1st is not loged, 2nd
        await timerLoadevent({ main: 0 }, 5000, "Authentication Error");
        return router.push("/");
      }
      //----------- Succefully Registered
      _this.value = Object.assign({}, resp.data);
      console.log(`\n User Acctype` + _this.value["acctype"] + ` \n`);
      //------------ Validate Acctype ?
      if (!(_this.value["acctype"] ?? false)) {
        await timerLoadevent({ main: 5000 }, 0, "Access Error, Retrying..");
        return router.push("/");
      }
      //----------- Loading Messages
      _profile_iss.value = _this.value["acctype"]["profile"] ?? null;
      await timerLoadevent({ main: 5000 }, 4000, "Ok");
      return true;
    })
    .catch(async (e) => {
      return await timerLoadevent({ main: 0 }, 0, "Error Connecting.." + e);
    });
};

//-----------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-----------ON-Mouted Operations and Authentications
//-----------Intializing....first functions and required datas
// var positionInstance = new _locationDevices(); //constructorialize navigator class
var _cameraInstance = new _cameraDevice();
var positionInstance = new _thisPosition(); //constructorialize navigator class
// let _informthis=ref(false)
timerLoadevent({ main: 0 }, 0, "Loading...");
onMounted(async () => {
  //onMounted
  // await timerLoadevent({ main: 7000 }, 0, "Please Wait..");
  //----------------onMoute Listen for scroll actions
  // window.addEventListener('scroll', handleScroll);
  return await _manageStoreLogin()
    .then(async (resp) => {
      //--------------ON MOUNT
      console.log(`\n<Loged IN> <==> Mining UserDevice Informations \n`);
      console.log("Initiating the API or TimeZone Locations System");
      _Country.value = await getCountry();
      console.log(_Country.value, "GET COUNTRY");
      _State.value = await getState();
      console.log(_State.value, "GET State");
      console.error(
        "Terminating the API or TimeZone Locations System, && INIT GeoData Mining using GPS or TimeZone GeoData !!! !"
      );
      positionInstance._init();
      //-----------------------
      console.log(
        `\n <==> Mining UserDevice Informations == positionInstance END, with Object == \n`,
        init_navObj.value
      );

      return true;
    })
    .catch(async (e) => {
      console.log("Loging IN Error <>", e);
      await timerLoadevent({ main: 0 }, 5000, "scrumbled privilege detected");
      return _logIn();
    });
});

// timerLoadpage(15000,"Loading...")
//Loadingpage.value = [{ content: "Loading..." }]; //it
onBeforeMount(async () => {
  //--------------ON MOUNT
  console.log("\n\n<---------Defaulting Profile <--this--> ---- \n");
  // await _thisDefaulting(); //Build Basic _this_default Schema ( same to columns)
  console.log(
    "\n\n---------Mining User Device Informations [Phones, GeoLocations]---- \n"
  );
});
_thisDefaulting();
//----------------------------------------
let excludedModals = ["user", "group", null, "", "home"];

let routeIt = async (_accDefault = null) => {
  if (
    excludedModals.includes(_accDefault) ||
    !(_this.value["acctype"] ?? false)
  ) {
    return false;
  }
  // await timerLoadevent({ main: 3000 }, 3000, "Loading " + _accDefault); //Message  [ wait 3 sec ] [reset]
  await timerLoadevent({ main: 0 }, 0, "Loading " + _accDefault); //Message display for unlimited sec,but  wait && don reset it

  try {
    let routePath = Object.assign(
      { acctype: _this.value["acctype"][_accDefault] ?? "" },
      _localStorage._reroute(
        _accDefault,
        _accDefault,
        screenSize.value == "Small"
      )
    );
    _updateStorage("path", _accDefault);
    await router.push(routePath);
    timerLoadevent({ main: 1 }, 1, "Ok, Loading " + _accDefault); //Message display for 3sec,but don wait && reset it
    return true; //
  } catch (e) {
    console.log(
      `\n\n</Routing Functions of pathName = ${_accDefault}  == >> ${e} == >>  \n`
    );
    timerLoadevent({ main: 3000 }, 3000, e);
    return false;
  }
};

let _logOut = async () => router.push(clearlogStatus());
let _logIn = async () => router.push("/");

//----------
let _pageSettings = ref({});
async function _setPageSetting(currency) {
  _pageSettings.value["tableView"] = _localStorage._get("tableView", "main");
  _pageSettings.value["currency"] = _localStorage._get("currency", "");
  //------------User Settings
  _pageSettings.value["language"] = _localStorage._get("language", 1);
  _pageSettings.value["languageOptions"] = ["Tigrigna", "English"];
  //-------------
  // _pageSettings.value['screenSize'] =screenSize.value
  //---
  _pageSettings.value["path"] = _localStorage._get("path", "saleit");
}

async function _updateStorage(key, value) {
  if (value) {
    _pageSettings.value[key] = value;
    _localStorage._set(key, toRaw(value));
  }
  return true;
}

//------------------------
let _openpubChat = ref(false);
let _chatting = ref({
  userID: _this.value.id,
  phone: _this.value.phone ?? 0,
  content: "",
});
async function openpubChat(_set) {
  _chatting.value.userID = _this.value.id;
  _chatting.value.phone = _this.value.phone;

  if (_set) {
    //-----enable box
    _openpubChat.value = !_openpubChat.value;
    return true;
  }
  return await publicchatService
    .createData(_chatting.value, { id: _this.value.id })
    .then((resp) => {
      if (resp) {
        _chatting.value.content = "";
      }
      return true;
    });
}

let _publiclive = ref("");
let _setpublicchat = ref(false);
let _chatWatch = ref(true);
_chatWatch = computed(() => {
  let a = _setpublicchat.value;
  if (a) {
    _liveChatting(2000);
  } else {
    _liveChatting(60000);
  }
  return a;
});
async function _liveChatting(period) {
  clearInterval(_publiclive.value);
  _publiclive.value = setInterval(publicchatService.asyncDatas, period);
  return true;
}
//
//------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@------------Modal CRUD_OPs
</script>

<style></style>
