

import hrdmicService from "./humdmicService/modelHRD";
import hrdmicService from "./finmicService/finance";



export  {hrdmicService,hrdmicService};

/*
module.exports = {
    Tutorial: require("./Tutorial"),
    Image: require("./Image"),
    Comment: require("./Comment"),
    Category: require("./Category")
  };

  */


