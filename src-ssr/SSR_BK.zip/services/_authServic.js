
const nul = [null, undefined, false, "", [], {}];
const acceType=['root','regAdmin','columnPower']

const mongodAcessSchema ={}

const modals =Object.keys(mongodAcessSchema)
async function accComputing(acessSchema){ //{'a':['v','b'],....}
return true
}

export { mongodAcessSchema,accComputing}