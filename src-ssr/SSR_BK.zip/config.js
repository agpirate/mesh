

//export default{

//const serverAPI_URL = "http://192.168.1.6:9100"; //server_api
const ssrAPI_PORT = 9100; //server_api
const serviceAAPI_ = 9000; //server_api
const serviceBAPI_ = 9000; //server_api
//const mongodAPI_URL = "mongodb://192.168.1.6:27017"; //database_api
const mongodAPI_URL = "mongodb://0.0.0.0:27017"; //database_api

export { mongodAPI_URL,ssrAPI_PORT };
